package CANADA;

import java.awt.EventQueue;
import VisaGUI.Tourist;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JCalendar;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JDialog;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;

public class CANADATour extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private final ButtonGroup Title = new ButtonGroup();
	private final ButtonGroup Gender = new ButtonGroup();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CANADATour frame = new CANADATour();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public CANADATour() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 895, 800);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(242, 242, 242));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        // Set the content pane
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(0, 0, 883, 500);
	    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	    contentPane.add(scrollPane);
	    
	    JPanel contentPane_1 = new JPanel();
	    contentPane_1.setPreferredSize(new Dimension(895, 700));
	    contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
	    contentPane_1.setBackground(new Color(250, 250, 250));
	    scrollPane.setViewportView(contentPane_1);
	    contentPane_1.setLayout(null);
	    
	    JPanel panel_1 = new JPanel();
	    panel_1.setLayout(null);
	    panel_1.setForeground(Color.WHITE);
	    panel_1.setBackground(new Color(214, 0, 36));
	    panel_1.setBounds(0, 56, 878, 32);
	    contentPane_1.add(panel_1);
	    
	    JLabel lblNewLabel_2 = new JLabel("Section-A");
	    lblNewLabel_2.setForeground(Color.WHITE);
	    lblNewLabel_2.setFont(new Font("Bell MT", Font.BOLD, 27));
	    lblNewLabel_2.setBounds(10, 0, 176, 32);
	    panel_1.add(lblNewLabel_2);
	    
	    JLabel nameLabel_1 = new JLabel("Name as shown in passport");
	    nameLabel_1.setForeground(Color.BLACK);
	    nameLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    nameLabel_1.setBackground(Color.WHITE);
	    nameLabel_1.setBounds(80, 105, 300, 30);
	    contentPane_1.add(nameLabel_1);
	    
	    textField = new JTextField();
	    textField.setForeground(Color.BLACK);
	    textField.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField.setBackground(Color.WHITE);
	    textField.setBounds(380, 105, 300, 30);
	    contentPane_1.add(textField);
	    
	    JLabel familyNameLabel_1 = new JLabel("Family/last name");
	    familyNameLabel_1.setForeground(Color.BLACK);
	    familyNameLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    familyNameLabel_1.setBackground(Color.WHITE);
	    familyNameLabel_1.setBounds(80, 145, 300, 30);
	    contentPane_1.add(familyNameLabel_1);
	    
	    textField_1 = new JTextField();
	    textField_1.setForeground(Color.BLACK);
	    textField_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField_1.setBackground(Color.WHITE);
	    textField_1.setBounds(380, 145, 300, 30);
	    contentPane_1.add(textField_1);
	    
	    JLabel givenNameLabel_1 = new JLabel("Given/first name(s)");
	    givenNameLabel_1.setForeground(Color.BLACK);
	    givenNameLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    givenNameLabel_1.setBackground(Color.WHITE);
	    givenNameLabel_1.setBounds(80, 185, 300, 30);
	    contentPane_1.add(givenNameLabel_1);
	    
	    textField_2 = new JTextField();
	    textField_2.setForeground(Color.BLACK);
	    textField_2.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField_2.setBackground(Color.WHITE);
	    textField_2.setBounds(380, 185, 300, 30);
	    contentPane_1.add(textField_2);
	    
	    JLabel titleLabel_1 = new JLabel("Preferred title");
	    titleLabel_1.setForeground(Color.BLACK);
	    titleLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    titleLabel_1.setBackground(Color.WHITE);
	    titleLabel_1.setBounds(80, 225, 300, 30);
	    contentPane_1.add(titleLabel_1);
	    
	    JLabel genderLabel_1 = new JLabel("Gender");
	    genderLabel_1.setForeground(Color.BLACK);
	    genderLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    genderLabel_1.setBackground(Color.WHITE);
	    genderLabel_1.setBounds(80, 265, 300, 30);
	    contentPane_1.add(genderLabel_1);
	    
	    JLabel dobLabel_1 = new JLabel("Date of birth");
	    dobLabel_1.setForeground(Color.BLACK);
	    dobLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    dobLabel_1.setBackground(Color.WHITE);
	    dobLabel_1.setBounds(80, 305, 300, 30);
	    contentPane_1.add(dobLabel_1);
	    
	    JLabel birthplaceLabel_1 = new JLabel("Town/city of birth");
	    birthplaceLabel_1.setForeground(Color.BLACK);
	    birthplaceLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    birthplaceLabel_1.setBackground(Color.WHITE);
	    birthplaceLabel_1.setBounds(80, 345, 300, 30);
	    contentPane_1.add(birthplaceLabel_1);
	    
	    textField_4 = new JTextField();
	    textField_4.setForeground(Color.BLACK);
	    textField_4.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField_4.setBackground(Color.WHITE);
	    textField_4.setBounds(380, 345, 300, 30);
	    contentPane_1.add(textField_4);
	    
	    JLabel birthCountryLabel_1 = new JLabel("Country/region of birth");
	    birthCountryLabel_1.setForeground(Color.BLACK);
	    birthCountryLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    birthCountryLabel_1.setBackground(Color.WHITE);
	    birthCountryLabel_1.setBounds(80, 385, 300, 30);
	    contentPane_1.add(birthCountryLabel_1);
	    
	    textField_5 = new JTextField();
	    textField_5.setForeground(Color.BLACK);
	    textField_5.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField_5.setBackground(Color.WHITE);
	    textField_5.setBounds(380, 385, 300, 30);
	    contentPane_1.add(textField_5);
	    
	    JLabel passportNumLabel_1 = new JLabel("Passport number");
	    passportNumLabel_1.setForeground(Color.BLACK);
	    passportNumLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    passportNumLabel_1.setBackground(Color.WHITE);
	    passportNumLabel_1.setBounds(80, 425, 300, 30);
	    contentPane_1.add(passportNumLabel_1);
	    
	    textField_6 = new JTextField();
	    textField_6.setForeground(Color.BLACK);
	    textField_6.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField_6.setBackground(Color.WHITE);
	    textField_6.setBounds(380, 425, 300, 30);
	    contentPane_1.add(textField_6);
	    
	    JLabel expiryDateLabel_1 = new JLabel("Passport expiration date");
	    expiryDateLabel_1.setForeground(Color.BLACK);
	    expiryDateLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    expiryDateLabel_1.setBackground(Color.WHITE);
	    expiryDateLabel_1.setBounds(80, 465, 300, 30);
	    contentPane_1.add(expiryDateLabel_1);
	    
	    textField_7 = new JTextField();
	    textField_7.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    textField_7.setBounds(380, 465, 300, 30);
	    contentPane_1.add(textField_7);
	    
	    JLabel countryLabel_1 = new JLabel("Country/region where you live");
	    countryLabel_1.setForeground(Color.BLACK);
	    countryLabel_1.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
	    countryLabel_1.setBounds(80, 505, 300, 30);
	    contentPane_1.add(countryLabel_1);
	    
	    textField_8 = new JTextField();
	    textField_8.setBounds(380, 505, 300, 30);
	    contentPane_1.add(textField_8);
	    
	    JLabel citizenshipLabel_1 = new JLabel("Citizenship");
	    citizenshipLabel_1.setForeground(Color.BLACK);
	    citizenshipLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    citizenshipLabel_1.setBounds(80, 545, 300, 30);
	    contentPane_1.add(citizenshipLabel_1);
	    
	    textField_9 = new JTextField();
	    textField_9.setBounds(380, 545, 300, 30);
	    contentPane_1.add(textField_9);
	    
	    JLabel otherCitizenshipLabel_1 = new JLabel("Other citizenship/nationality");
	    otherCitizenshipLabel_1.setForeground(Color.BLACK);
	    otherCitizenshipLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    otherCitizenshipLabel_1.setBounds(80, 585, 300, 30);
	    contentPane_1.add(otherCitizenshipLabel_1);
	    
	    textField_10 = new JTextField();
	    textField_10.setBounds(380, 585, 300, 30);
	    contentPane_1.add(textField_10);
	    
	    JButton btnNewButton_1 = new JButton("Back");
	    btnNewButton_1.setFont(new Font("SansSerif", Font.BOLD, 12));
	    btnNewButton_1.setBackground(Color.LIGHT_GRAY);
	    btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        	Tourist tv = new Tourist();
		        	tv.setVisible(true);
					tv.setBounds(100, 100, 895, 500);
					tv.dispose();
			}
		});
	    btnNewButton_1.setBounds(273, 642, 90, 30);
	    contentPane_1.add(btnNewButton_1);
	    
	    JButton btnNext_1 = new JButton("Next");
	    btnNext_1.setForeground(Color.WHITE);
	    btnNext_1.setFont(new Font("SansSerif", Font.BOLD, 12));
	    btnNext_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || 
						textField_4.getText().isEmpty()|| textField_5.getText().isEmpty() || 
						textField_6.getText().isEmpty()|| textField_7.getText().isEmpty() || textField_8.getText().isEmpty()|| 
						textField_9.getText().isEmpty() || textField_10.getText().isEmpty()) {
		            JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
		        } else {
		        	CanBTour canb = new CanBTour();
		        	canb.setVisible(true);
					canb.setBounds(100, 100, 895, 500);
					canb.dispose();
		        }
			}
		});
	    btnNext_1.setBackground(new Color(214, 0, 36));
	    btnNext_1.setBounds(440, 642, 90, 30);
	    contentPane_1.add(btnNext_1);
	    
	    JLabel lblNewLabel_1_1 = new JLabel(" GOVERNMENT OF CANADA");
	    lblNewLabel_1_1.setForeground(new Color(214, 0, 36));
	    lblNewLabel_1_1.setFont(new Font("Century", Font.BOLD, 35));
	    lblNewLabel_1_1.setBounds(0, 0, 709, 54);
	    contentPane_1.add(lblNewLabel_1_1);
	    
	    JButton btnNewButton = new JButton("");
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	   		 JDialog dialog = new JDialog(CANADATour.this, "Select Date", true);
      	    JPanel panel = new JPanel();
      	    JCalendar calendar = new JCalendar();
      	    calendar.setTodayButtonVisible(true);
      	    calendar.setNullDateButtonVisible(true); // allow selection of today's date
      	    panel.add(calendar);
      	    JButton btnNewButton = new JButton("OK");
      	    btnNewButton.addActionListener(new ActionListener() {
      	        public void actionPerformed(ActionEvent e) {
      	            // Get the selected date from the calendar
      	            Calendar selectedDate = calendar.getCalendar();
      	            if (selectedDate != null) {
      	                // Format the date in "MM/dd/yyyy" format
      	                String formattedDate = String.format("%1$td/%1$tm/%1$tY", selectedDate.getTime());
      	                // Change the text of the button to the selected date
      	                btnNewButton.setText(formattedDate);
      	            }
      	            dialog.dispose();
      	        }
      	    });
      	    panel.add(btnNewButton);
      	    dialog.getContentPane().add(panel);
      	    dialog.pack();
      	    dialog.setLocationRelativeTo(CANADATour.this);
      	    dialog.setVisible(true);
	    	}
	    });
	    btnNewButton.setBackground(Color.WHITE);
	    btnNewButton.setBounds(380, 302, 300, 30);
	    contentPane_1.add(btnNewButton);
	    
	    JRadioButton rdbtnMale = new JRadioButton("Male");
	    Gender.add(rdbtnMale);
	    rdbtnMale.setForeground(Color.BLACK);
	    rdbtnMale.setFont(new Font("Dialog", Font.PLAIN, 11));
	    rdbtnMale.setBackground(new Color(250, 250, 250));
	    rdbtnMale.setBounds(380, 265, 56, 23);
	    contentPane_1.add(rdbtnMale);
	    
	    JRadioButton rdbtnFemale = new JRadioButton("Female");
	    Gender.add(rdbtnFemale);
	    rdbtnFemale.setForeground(Color.BLACK);
	    rdbtnFemale.setFont(new Font("Dialog", Font.PLAIN, 11));
	    rdbtnFemale.setBackground(new Color(250, 250, 250));
	    rdbtnFemale.setBounds(447, 266, 69, 23);
	    contentPane_1.add(rdbtnFemale);
	    
	    JRadioButton rdbtnMrs = new JRadioButton("Mrs.");
	    Title.add(rdbtnMrs);
	    rdbtnMrs.setForeground(Color.BLACK);
	    rdbtnMrs.setFont(new Font("Dialog", Font.PLAIN, 11));
	    rdbtnMrs.setBackground(new Color(250, 250, 250));
	    rdbtnMrs.setBounds(428, 226, 56, 23);
	    contentPane_1.add(rdbtnMrs);
	    
	    JRadioButton rdbtnMr = new JRadioButton("Mr.");
	    Title.add(rdbtnMr);
	    rdbtnMr.setForeground(Color.BLACK);
	    rdbtnMr.setFont(new Font("Dialog", Font.PLAIN, 11));
	    rdbtnMr.setBackground(new Color(250, 250, 250));
	    rdbtnMr.setBounds(380, 226, 41, 23);
	    contentPane_1.add(rdbtnMr);
	    
	    JRadioButton rdbtnMs = new JRadioButton("Ms.");
	    Title.add(rdbtnMs);
	    rdbtnMs.setForeground(Color.BLACK);
	    rdbtnMs.setFont(new Font("Dialog", Font.PLAIN, 11));
	    rdbtnMs.setBackground(new Color(250, 250, 250));
	    rdbtnMs.setBounds(496, 226, 49, 23);
	    contentPane_1.add(rdbtnMs);
	    
	    JRadioButton rdbtnMiss = new JRadioButton("Miss");
	    Title.add(rdbtnMiss);
	    rdbtnMiss.setForeground(Color.BLACK);
	    rdbtnMiss.setFont(new Font("Dialog", Font.PLAIN, 11));
	    rdbtnMiss.setBackground(new Color(250, 250, 250));
	    rdbtnMiss.setBounds(555, 226, 56, 23);
	    contentPane_1.add(rdbtnMiss);
        
        // Set window properties
        setTitle("USA Visa Application Form");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(895, 887);
        setVisible(true);
    }
}
