package CANADA;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

public class CanBTour extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private final ButtonGroup YesNo = new ButtonGroup();
	private final ButtonGroup Address = new ButtonGroup();
	private JTextField textField_4;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CanBTour frame = new CanBTour();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public CanBTour() {
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 895, 941);
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(255, 255, 255));
	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	    setContentPane(contentPane);
	    // Set the content pane layout to null for absolute positioning
	    contentPane.setLayout(null);
	    
	    // Create the scroll pane with the fixed size
	    JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(0, 0, 882, 500);
	    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	    contentPane.add(scrollPane);
	    
	    JPanel contentPane_1 = new JPanel();
	    contentPane_1.setPreferredSize(new Dimension(895, 830));
	    contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
	    contentPane_1.setBackground(new Color(250, 250, 250));
	    scrollPane.setViewportView(contentPane_1);
	    contentPane_1.setLayout(null);
	    
	    JLabel nameLabel = new JLabel("Your residential address in your home country. ");
	    nameLabel.setForeground(Color.BLACK);
	    nameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    nameLabel.setBackground(Color.WHITE);
	    nameLabel.setBounds(76, 101, 300, 39);
	    contentPane_1.add(nameLabel);
	    
	    textField = new JTextField();
	    textField.setForeground(Color.BLACK);
	    textField.setBackground(Color.WHITE);
	    textField.setBounds(376, 101, 300, 30);
	    contentPane_1.add(textField);
	    
	    JLabel familyNameLabel = new JLabel("Telephone number in your home country. ");
	    familyNameLabel.setForeground(Color.BLACK);
	    familyNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    familyNameLabel.setBackground(Color.WHITE);
	    familyNameLabel.setBounds(76, 141, 300, 30);
	    contentPane_1.add(familyNameLabel);
	    
	    textField_1 = new JTextField();
	    textField_1.setForeground(Color.BLACK);
	    textField_1.setBackground(Color.WHITE);
	    textField_1.setBounds(376, 141, 300, 30);
	    contentPane_1.add(textField_1);
	    
	    JLabel givenNameLabel = new JLabel("<html>Name and address for communication<br>about this application.</html>");
	    givenNameLabel.setForeground(Color.BLACK);
	    givenNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    givenNameLabel.setBackground(Color.WHITE);
	    givenNameLabel.setBounds(76, 181, 300, 30);
	    contentPane_1.add(givenNameLabel);
	    
	    textField_2 = new JTextField();
	    textField_2.setForeground(Color.BLACK);
	    textField_2.setBackground(Color.WHITE);
	    textField_2.setBounds(376, 264, 300, 30);
	    contentPane_1.add(textField_2);
	    
	    JLabel birthplaceLabel = new JLabel("Telephone Number");
	    birthplaceLabel.setForeground(Color.BLACK);
	    birthplaceLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    birthplaceLabel.setBackground(Color.WHITE);
	    birthplaceLabel.setBounds(76, 344, 300, 30);
	    contentPane_1.add(birthplaceLabel);
	    
	    textField_3 = new JTextField();
	    textField_3.setForeground(Color.BLACK);
	    textField_3.setBackground(Color.WHITE);
	    textField_3.setBounds(376, 305, 300, 30);
	    contentPane_1.add(textField_3);
	    
	    JLabel citizenshipLabel = new JLabel("<html>Are you a lawful Permanent Resident of the United States with a valid alien registration card (green card)?<html>");
	    citizenshipLabel.setForeground(Color.BLACK);
	    citizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    citizenshipLabel.setBackground(Color.WHITE);
	    citizenshipLabel.setBounds(72, 668, 285, 54);
	    contentPane_1.add(citizenshipLabel);
	    
	    JPanel panel_1 = new JPanel();
	    panel_1.setLayout(null);
	    panel_1.setForeground(Color.BLACK);
	    panel_1.setBackground(new Color(214, 0, 36));
	    panel_1.setBounds(1, 51, 883, 32);
	    contentPane_1.add(panel_1);
	    
	    JLabel lblNewLabel = new JLabel("Section-B");
	    lblNewLabel.setForeground(Color.WHITE);
	    lblNewLabel.setFont(new Font("Castellar", Font.BOLD, 25));
	    lblNewLabel.setBounds(10, 0, 176, 32);
	    panel_1.add(lblNewLabel);
	    
	    JLabel familyNameLabel_1 = new JLabel("Family/last name");
	    familyNameLabel_1.setForeground(Color.BLACK);
	    familyNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    familyNameLabel_1.setBackground(Color.WHITE);
	    familyNameLabel_1.setBounds(76, 263, 300, 30);
	    contentPane_1.add(familyNameLabel_1);
	    
	    JLabel givenNameLabel_1 = new JLabel("Given/first name(s)");
	    givenNameLabel_1.setForeground(Color.BLACK);
	    givenNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    givenNameLabel_1.setBackground(Color.WHITE);
	    givenNameLabel_1.setBounds(76, 303, 300, 30);
	    contentPane_1.add(givenNameLabel_1);
	    
	    textField_6 = new JTextField();
	    textField_6.setForeground(Color.BLACK);
	    textField_6.setBackground(Color.WHITE);
	    textField_6.setBounds(376, 344, 300, 30);
	    contentPane_1.add(textField_6);
	    
	    textField_7 = new JTextField();
	    textField_7.setForeground(Color.BLACK);
	    textField_7.setBackground(Color.WHITE);
	    textField_7.setBounds(376, 382, 300, 30);
	    contentPane_1.add(textField_7);
	    
	    JLabel lblEmail = new JLabel("Email");
	    lblEmail.setForeground(Color.BLACK);
	    lblEmail.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    lblEmail.setBackground(Color.WHITE);
	    lblEmail.setBounds(76, 385, 300, 30);
	    contentPane_1.add(lblEmail);
	    
	    JPanel panel_1_1 = new JPanel();
	    panel_1_1.setLayout(null);
	    panel_1_1.setForeground(Color.WHITE);
	    panel_1_1.setBackground(new Color(214, 0, 36));
	    panel_1_1.setBounds(1, 425, 883, 32);
	    contentPane_1.add(panel_1_1);
	    
	    JLabel lblSectione = new JLabel("Section-C");
	    lblSectione.setForeground(Color.WHITE);
	    lblSectione.setFont(new Font("Castellar", Font.BOLD, 25));
	    lblSectione.setBounds(10, 0, 176, 32);
	    panel_1_1.add(lblSectione);
	    
	    JButton btnNewButton = new JButton("Back");
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    	}
	    });
	    btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 12));
	    btnNewButton.setBackground(Color.LIGHT_GRAY);
	    btnNewButton.setBounds(269, 780, 90, 30);
	    contentPane_1.add(btnNewButton);
	    
	    JButton btnNext = new JButton("Next");
	    btnNext.setForeground(Color.WHITE);
	    btnNext.setFont(new Font("Serif", Font.BOLD, 14));
	    btnNext.setBackground(Color.RED);
	    btnNext.setBounds(431, 780, 90, 30);
	    contentPane_1.add(btnNext);
	    
	    JLabel lblNewLabel_1_1 = new JLabel("GOVERNMENT OF CANADA");
	    lblNewLabel_1_1.setForeground(new Color(214, 0, 36));
	    lblNewLabel_1_1.setFont(new Font("Castellar", Font.BOLD, 35));
	    lblNewLabel_1_1.setBackground(Color.WHITE);
	    lblNewLabel_1_1.setBounds(1, 43, 639, 54);
	    contentPane_1.add(lblNewLabel_1_1);
	    
	    JRadioButton rdbtnNewRadioButton = new JRadioButton("Yes");
	    YesNo.add(rdbtnNewRadioButton);
	    rdbtnNewRadioButton.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNewRadioButton.setBounds(376, 678, 61, 23);
	    contentPane_1.add(rdbtnNewRadioButton);
	    
	    JRadioButton rdbtnNo = new JRadioButton("No");
	    YesNo.add(rdbtnNo);
	    rdbtnNo.setBackground(new Color(250, 250, 250));
	    rdbtnNo.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNo.setBounds(461, 678, 109, 23);
	    contentPane_1.add(rdbtnNo);
	    
	    textField_8 = new JTextField();
	    textField_8.setForeground(Color.BLACK);
	    textField_8.setBackground(Color.WHITE);
	    textField_8.setBounds(376, 211, 300, 42);
	    contentPane_1.add(textField_8);
	    
	    JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Same as address provided ");
	    rdbtnNewRadioButton_1.setFont(new Font("Dialog", Font.PLAIN, 12));
	    Address.add(rdbtnNewRadioButton_1);
	    rdbtnNewRadioButton_1.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton_1.setBounds(376, 177, 180, 23);
	    contentPane_1.add(rdbtnNewRadioButton_1);
	    
	    JRadioButton rdbtnNewRadioButton_1_1 = new JRadioButton("As Below");
	    rdbtnNewRadioButton_1_1.setFont(new Font("Dialog", Font.PLAIN, 12));
	    Address.add(rdbtnNewRadioButton_1_1);
	    rdbtnNewRadioButton_1_1.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton_1_1.setBounds(558, 177, 109, 23);
	    contentPane_1.add(rdbtnNewRadioButton_1_1);
	    
	    JLabel lblNewLabel_1 = new JLabel(" GOVERNMENT OF CANADA");
	    lblNewLabel_1.setForeground(new Color(214, 0, 36));
	    lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 33));
	    lblNewLabel_1.setBounds(1, 0, 649, 54);
	    contentPane_1.add(lblNewLabel_1);
	    
	    JLabel expiryDateLabel = new JLabel("Visa that you are applying for");
	    expiryDateLabel.setForeground(Color.BLACK);
	    expiryDateLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    expiryDateLabel.setBounds(72, 472, 244, 30);
	    contentPane_1.add(expiryDateLabel);
	    
	    JComboBox<Object> comboBox = new JComboBox<Object>();
	    comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Select an Option", "B-1 ", "B-2", "Transit C", "Transit C-1,D"}));
	    comboBox.setBounds(376, 473, 300, 30);
	    contentPane_1.add(comboBox);
	    
	    textField_4 = new JTextField();
	    textField_4.setBounds(376, 520, 300, 30);
	    contentPane_1.add(textField_4);
	    
	    JLabel citizenshipLabel_1 = new JLabel("<html>Proof of the purpose of your stay<html>");
	    citizenshipLabel_1.setForeground(Color.BLACK);
	    citizenshipLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    citizenshipLabel_1.setBounds(72, 519, 218, 30);
	    contentPane_1.add(citizenshipLabel_1);
	    
	    JLabel otherCitizenshipLabel = new JLabel("Proof of your intent to depart the US");
	    otherCitizenshipLabel.setForeground(Color.BLACK);
	    otherCitizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    otherCitizenshipLabel.setBounds(72, 568, 251, 30);
	    contentPane_1.add(otherCitizenshipLabel);
	    
	    textField_9 = new JTextField();
	    textField_9.setColumns(10);
	    textField_9.setBounds(376, 569, 300, 30);
	    contentPane_1.add(textField_9);
	    
	    textField_10 = new JTextField();
	    textField_10.setColumns(10);
	    textField_10.setBounds(376, 616, 300, 30);
	    contentPane_1.add(textField_10);
	    
	    JLabel lblNewLabel_2 = new JLabel("<html>Proof of your ability to pay all the costs <br>of the trip</html>");
	    lblNewLabel_2.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    lblNewLabel_2.setBounds(72, 619, 267, 39);
	    contentPane_1.add(lblNewLabel_2);
	    
	    JLabel lblDocumentNumber = new JLabel("Document number(If Yes then only)");
	    lblDocumentNumber.setForeground(Color.BLACK);
	    lblDocumentNumber.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    lblDocumentNumber.setBackground(Color.WHITE);
	    lblDocumentNumber.setBounds(72, 727, 267, 30);
	    contentPane_1.add(lblDocumentNumber);
	    
	    textField_11 = new JTextField();
	    textField_11.setColumns(10);
	    textField_11.setBounds(376, 724, 300, 30);
	    contentPane_1.add(textField_11);
	    
	}
}