package CANADA;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.awt.event.ActionEvent;
import javax.swing.JLayeredPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class CanadaB extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_4;
	private JTextField textField_5;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private JTextField textField_9;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CanadaB frame = new CanadaB();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public CanadaB() {
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 895, 910);
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(255, 255, 255));
	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	    setContentPane(contentPane);
	    // Set the content pane layout to null for absolute positioning
	    contentPane.setLayout(null);
	    
	    // Create the scroll pane with the fixed size
	    JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(0, 0, 884, 500);
	    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	    contentPane.add(scrollPane);
	    
	    JPanel contentPane_1 = new JPanel();
	    contentPane_1.setPreferredSize(new Dimension(895, 800)); 
	    contentPane_1.setLayout(null);
	    contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
	    contentPane_1.setBackground(new Color(250, 250, 250));
	    scrollPane.setViewportView(contentPane_1);
	    
	    JLabel nameLabel = new JLabel("Your residential address in your home country. ");
	    nameLabel.setBackground(new Color(255, 255, 255));
	    nameLabel.setForeground(new Color(0, 0, 0));
	    nameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    nameLabel.setBounds(75, 100, 300, 39);
	    contentPane_1.add(nameLabel);
	    
	    textField = new JTextField();
	    textField.setBackground(new Color(255, 255, 255));
	    textField.setForeground(new Color(0, 0, 0));
	    textField.setBounds(375, 100, 300, 30);
	    contentPane_1.add(textField);
	    
	    JLabel familyNameLabel = new JLabel("Telephone number in your home country. ");
	    familyNameLabel.setBackground(new Color(255, 255, 255));
	    familyNameLabel.setForeground(new Color(0, 0, 0));
	    familyNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    familyNameLabel.setBounds(75, 140, 300, 30);
	    contentPane_1.add(familyNameLabel);
	    
	    textField_1 = new JTextField();
	    textField_1.setBackground(new Color(255, 255, 255));
	    textField_1.setForeground(new Color(0, 0, 0));
	    textField_1.setBounds(375, 140, 300, 30);
	    contentPane_1.add(textField_1);
	    
	    JLayeredPane layeredPane = new JLayeredPane();
	    layeredPane.setBounds(0, 0, 1, 1);
	    contentPane_1.add(layeredPane);
	    
	    JLabel givenNameLabel = new JLabel("<html>Name and address for communication<br>about this application.</html>");
	    givenNameLabel.setBackground(new Color(255, 255, 255));
	    givenNameLabel.setForeground(new Color(0, 0, 0));
	    givenNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    givenNameLabel.setBounds(75, 180, 300, 30);
	    contentPane_1.add(givenNameLabel);
	    
	    textField_2 = new JTextField();
	    textField_2.setBackground(new Color(255, 255, 255));
	    textField_2.setForeground(new Color(0, 0, 0));
	    textField_2.setBounds(375, 241, 300, 30);
	    contentPane_1.add(textField_2);
	    
	    JLabel birthplaceLabel = new JLabel("Telephone Number");
	    birthplaceLabel.setBackground(new Color(255, 255, 255));
	    birthplaceLabel.setForeground(new Color(0, 0, 0));
	    birthplaceLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    birthplaceLabel.setBounds(75, 321, 300, 30);
	    contentPane_1.add(birthplaceLabel);
	    
	    textField_3 = new JTextField();
	    textField_3.setBackground(new Color(255, 255, 255));
	    textField_3.setForeground(new Color(0, 0, 0));
	    textField_3.setBounds(375, 282, 300, 30);
	    contentPane_1.add(textField_3);
	    
	    JLabel countryLabel = new JLabel("DS-160");
	    countryLabel.setBackground(new Color(255, 255, 255));
	    countryLabel.setForeground(new Color(0, 0, 0));
	    countryLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    countryLabel.setBounds(75, 624, 63, 30);
	    contentPane_1.add(countryLabel);
	    
	    JLabel citizenshipLabel = new JLabel("<html>Provide the date to which your course fees have been paid. If you have a scholarship, <br>provide the date your scholarship ends<html>");
	    citizenshipLabel.setBackground(new Color(255, 255, 255));
	    citizenshipLabel.setForeground(new Color(0, 0, 0));
	    citizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    citizenshipLabel.setBounds(75, 547, 300, 71);
	    contentPane_1.add(citizenshipLabel);
	    
	    JLabel otherCitizenshipLabel = new JLabel("Course you have enrolled in");
	    otherCitizenshipLabel.setBackground(new Color(255, 255, 255));
	    otherCitizenshipLabel.setForeground(new Color(0, 0, 0));
	    otherCitizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    otherCitizenshipLabel.setBounds(69, 677, 251, 30);
	    contentPane_1.add(otherCitizenshipLabel);
	    
	    textField_6 = new JTextField();
	    textField_6.setBackground(new Color(255, 255, 255));
	    textField_6.setForeground(new Color(0, 0, 0));
	    textField_6.setBounds(375, 569, 300, 30);
	    contentPane_1.add(textField_6);
	    
	    JPanel panel_1 = new JPanel();
	    panel_1.setBackground(new Color(214, 0, 36));
	    panel_1.setForeground(new Color(0, 0, 0));
	    panel_1.setLayout(null);
	    panel_1.setBounds(0, 51, 883, 32);
	    contentPane_1.add(panel_1);
	    
	    JLabel lblNewLabel = new JLabel("Section-B");
	    lblNewLabel.setForeground(new Color(255, 255, 255));
	    lblNewLabel.setFont(new Font("Castellar", Font.BOLD, 25));
	    lblNewLabel.setBounds(10, 0, 176, 32);
	    panel_1.add(lblNewLabel);
	    
	    JLabel familyNameLabel_1 = new JLabel("Family/last name");
	    familyNameLabel_1.setBackground(new Color(255, 255, 255));
	    familyNameLabel_1.setForeground(new Color(0, 0, 0));
	    familyNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    familyNameLabel_1.setBounds(75, 240, 300, 30);
	    contentPane_1.add(familyNameLabel_1);
	    
	    JLabel givenNameLabel_1 = new JLabel("Given/first name(s)");
	    givenNameLabel_1.setBackground(new Color(255, 255, 255));
	    givenNameLabel_1.setForeground(new Color(0, 0, 0));
	    givenNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    givenNameLabel_1.setBounds(75, 280, 300, 30);
	    contentPane_1.add(givenNameLabel_1);
	    
	    textField_7 = new JTextField();
	    textField_7.setBackground(new Color(255, 255, 255));
	    textField_7.setForeground(new Color(0, 0, 0));
	    textField_7.setBounds(375, 321, 300, 30);
	    contentPane_1.add(textField_7);
	    
	    textField_8 = new JTextField();
	    textField_8.setBackground(new Color(255, 255, 255));
	    textField_8.setForeground(new Color(0, 0, 0));
	    textField_8.setBounds(375, 359, 300, 30);
	    contentPane_1.add(textField_8);
	    
	    JLabel lblEmail = new JLabel("Email");
	    lblEmail.setBackground(new Color(255, 255, 255));
	    lblEmail.setForeground(new Color(0, 0, 0));
	    lblEmail.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    lblEmail.setBounds(75, 362, 300, 30);
	    contentPane_1.add(lblEmail);
	    
	    JPanel panel_1_1 = new JPanel();
	    panel_1_1.setForeground(new Color(255, 255, 255));
	    panel_1_1.setBackground(new Color(214, 0, 36));
	    panel_1_1.setLayout(null);
	    panel_1_1.setBounds(0, 407, 883, 32);
	    contentPane_1.add(panel_1_1);
	    
	    JLabel lblSectione = new JLabel("Section-C");
	    lblSectione.setForeground(new Color(255, 255, 255));
	    lblSectione.setFont(new Font("Castellar", Font.BOLD, 25));
	    lblSectione.setBounds(10, 0, 176, 32);
	    panel_1_1.add(lblSectione);
	      
	    JButton btnNewButton = new JButton("Back");
	    btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 12));
	    btnNewButton.setBackground(new Color(192, 192, 192));
	    btnNewButton.setBounds(263, 740, 114, 30);
	    btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CANADA CAN = new CANADA();
				CAN.setBounds(100, 100, 895, 500);
				dispose();
			}
		});
	    contentPane_1.add(btnNewButton);
	    
	    JButton btnNext = new JButton("Next");
	    btnNext.setForeground(new Color(255, 255, 255));
	    btnNext.setBackground(new Color(255, 0, 0));
	    btnNext.setFont(new Font("Serif", Font.BOLD, 14));
	    btnNext.setBounds(419, 739, 114, 30);
	    contentPane_1.add(btnNext);
	    btnNext.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	            if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || 
	            		textField_3.getText().isEmpty() || textField_4.getText().isEmpty() || textField_5.getText().isEmpty() || 
	            		textField_6.getText().isEmpty() || textField_7.getText().isEmpty() ||textField_8.getText().isEmpty()) {
	                JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
	            } else {
	            	CanadaC usc = new CanadaC();
					usc.setVisible(true);
					usc.setBounds(100,100,895,500);
					dispose();
	            }
	        }
	    });
	    
	    JLabel lblNewLabel_1_1 = new JLabel("GOVERNMENT OF CANADA");
	    lblNewLabel_1_1.setForeground(new Color(214, 0, 36));
	    lblNewLabel_1_1.setFont(new Font("Castellar", Font.BOLD, 35));
	    lblNewLabel_1_1.setBackground(Color.WHITE);
	    lblNewLabel_1_1.setBounds(0, 0, 639, 54);
	    contentPane_1.add(lblNewLabel_1_1);
	    
	    JButton btnNewButton_1_1 = new JButton("Upload Document");
	    btnNewButton_1_1.setBackground(new Color(255, 255, 255));
	    btnNewButton_1_1.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            JFileChooser fileChooser = new JFileChooser();
	            int returnValue = fileChooser.showOpenDialog(null);
	            if (returnValue == JFileChooser.APPROVE_OPTION) {
	                File selectedFile = fileChooser.getSelectedFile();
	                try {
	                    // Copy the selected file to the desired location
	                	Files.copy(selectedFile.toPath(), Paths.get("Uploads/" + selectedFile.getName()));

	                    // Show success message
	                    JOptionPane.showMessageDialog(null, "File uploaded successfully.");
	                } catch (IOException ex) {
	                    // Show error message
	                    JOptionPane.showMessageDialog(null, "Error uploading file: " + ex.getMessage());
	                }
	            }
	        }
	    });
	    btnNewButton_1_1.setBounds(375, 624, 300, 30);
	    contentPane_1.add(btnNewButton_1_1);
	    
	    JLabel citizenshipLabel_1 = new JLabel("<html>Are you a lawful Permanent Resident of the United States with a valid alien registration card (green card)?<html>");
	    citizenshipLabel_1.setForeground(Color.BLACK);
	    citizenshipLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    citizenshipLabel_1.setBackground(Color.WHITE);
	    citizenshipLabel_1.setBounds(75, 462, 300, 54);
	    contentPane_1.add(citizenshipLabel_1);
	    
	    JLabel lblDocumentNumber = new JLabel("Document number(If Yes then only)");
	    lblDocumentNumber.setForeground(Color.BLACK);
	    lblDocumentNumber.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    lblDocumentNumber.setBackground(Color.WHITE);
	    lblDocumentNumber.setBounds(75, 517, 267, 30);
	    contentPane_1.add(lblDocumentNumber);
	    
	    textField_4 = new JTextField();
	    textField_4.setColumns(10);
	    textField_4.setBounds(375, 514, 300, 30);
	    contentPane_1.add(textField_4);
	    
	    JRadioButton rdbtnNewRadioButton = new JRadioButton("Yes");
	    buttonGroup_1.add(rdbtnNewRadioButton);
	    rdbtnNewRadioButton.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNewRadioButton.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton.setBounds(377, 473, 61, 23);
	    contentPane_1.add(rdbtnNewRadioButton);
	    
	    JRadioButton rdbtnNo = new JRadioButton("No");
	    buttonGroup_1.add(rdbtnNo);
	    rdbtnNo.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNo.setBackground(new Color(250, 250, 250));
	    rdbtnNo.setBounds(464, 473, 109, 23);
	    contentPane_1.add(rdbtnNo);
	    
	    textField_5 = new JTextField();
	    textField_5.setForeground(Color.BLACK);
	    textField_5.setBackground(Color.WHITE);
	    textField_5.setBounds(375, 203, 300, 30);
	    contentPane_1.add(textField_5);
	    
	    JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Same as address provided ");
	    buttonGroup.add(rdbtnNewRadioButton_1);
	    rdbtnNewRadioButton_1.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNewRadioButton_1.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton_1.setBounds(373, 180, 180, 23);
	    contentPane_1.add(rdbtnNewRadioButton_1);
	    
	    JRadioButton rdbtnNewRadioButton_1_1 = new JRadioButton("As Below");
	    buttonGroup.add(rdbtnNewRadioButton_1_1);
	    rdbtnNewRadioButton_1_1.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNewRadioButton_1_1.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton_1_1.setBounds(555, 180, 109, 23);
	    contentPane_1.add(rdbtnNewRadioButton_1_1);
	    
	    textField_9 = new JTextField();
	    textField_9.setForeground(Color.BLACK);
	    textField_9.setBackground(Color.WHITE);
	    textField_9.setBounds(375, 677, 300, 30);
	    contentPane_1.add(textField_9);
	}
}
