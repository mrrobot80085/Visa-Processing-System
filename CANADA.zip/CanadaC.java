package CANADA;

import java.awt.EventQueue;
import VisaGUI.HomeLog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DateFormatter;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class CanadaC extends JFrame {

	private static final long serialVersionUID = 1L;
	protected static final String Dialog = null;
	private JPanel contentPane;
	private JTextField textField_1;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CanadaC frame = new CanadaC();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CanadaC() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 895, 940);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPanel1 = new JPanel();
		contentPanel1.setBackground(new Color(242, 242, 242));
		contentPanel1.setPreferredSize(new Dimension(873, 550));
		contentPanel1.setLayout(null);

		JScrollPane contentScrollPane = new JScrollPane(contentPanel1, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
		                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contentScrollPane.setBackground(new Color(0, 0, 64));
        
        contentPane.add(contentScrollPane);
        		
        		textField_1 = new JTextField();
        		textField_1.setColumns(10);
        		textField_1.setBounds(227, 435, 170, 30);
        		contentPanel1.add(textField_1);
        		
        		JLabel lblNewLabel_2 = new JLabel("Signature of applicant:");
        		lblNewLabel_2.setForeground(new Color(0, 0, 0));
        		lblNewLabel_2.setFont(new Font("Javanese Text", Font.PLAIN, 18));
        		lblNewLabel_2.setBounds(36, 439, 192, 26);
        		contentPanel1.add(lblNewLabel_2);
        		
        		JLabel lblNewLabel_2_1 = new JLabel("Date:");
        		lblNewLabel_2_1.setForeground(new Color(0, 0, 0));
        		lblNewLabel_2_1.setFont(new Font("Javanese Text", Font.PLAIN, 18));
        		lblNewLabel_2_1.setBounds(518, 441, 57, 23);
        		contentPanel1.add(lblNewLabel_2_1);
        		
        		JPanel panel = new JPanel();
        		panel.setBackground(new Color(214, 0, 36));
        		panel.setLayout(null);
        		panel.setBounds(0, 51, 883, 32);
        		contentPanel1.add(panel);
        		
        		JLabel lblSection = new JLabel("Section-D");
        		lblSection.setForeground(new Color(255, 255, 255));
        		lblSection.setBackground(new Color(255, 255, 255));
        		lblSection.setFont(new Font("Castellar", Font.BOLD, 25));
        		lblSection.setBounds(10, 0, 176, 32);
        		panel.add(lblSection);
        		
        		JLabel lblNewLabel = new JLabel("<html>Citizenship and Immigration Canada (CIC), or an organization at (IC' request, may want to contact you in the future to ask you <br>about any services you received from CIC prior to the application process (such as participation in an information forum), <br>during the application process (including the application process itself as well as orientation or accreditation services), an <br>services received after arriving in Canada (including settlement, integration and citizenship).<br><br>CIC will use this information, along with the information provided by other individuals, for research, performance measurement <br>or evaluation purposes. CIC will not use this information to make any decisions about you personally.<br><br>Do you consent to be contacted by CIC, or an organization at CIC's request, in the future? </html>");
        		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
        		lblNewLabel.setBackground(new Color(0, 0, 0));
        		lblNewLabel.setForeground(new Color(0, 0, 0));
        		lblNewLabel.setFont(new Font("Lucida Bright", Font.BOLD, 12));
        		lblNewLabel.setBounds(10, 92, 849, 139);
        		contentPanel1.add(lblNewLabel);
        		
        		JButton btnNewButton = new JButton("Back");
        		btnNewButton.setBackground(new Color(192, 192, 192));
        		btnNewButton.setFont(new Font("Leelawadee UI", Font.BOLD, 14));
        		btnNewButton.setBounds(309, 490, 89, 23);
        		contentPanel1.add(btnNewButton);
        
        		JLabel lblNewLabel_1 = new JLabel(" GOVERNMENT OF CANADA");
        		lblNewLabel_1.setForeground(new Color(214, 0, 36));
        		lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 33));
        		lblNewLabel_1.setBounds(0, 0, 649, 54);
        		contentPanel1.add(lblNewLabel_1);
        		
        		JButton btnPay = new JButton("PAY");
        		btnPay.setForeground(new Color(255, 255, 255));
        		btnPay.addActionListener(new ActionListener() {
        			public void actionPerformed(ActionEvent e) {
        				if (textField_1.getText().isEmpty()) {
        		            JOptionPane.showMessageDialog(null, "Please fill in all the required fields");
        		        } else {
        		        	
        		            JDialog dialog = new JDialog();
        		            dialog.setTitle("Payment Information");
        		            dialog.setSize(600, 400);
        		            dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        		            dialog.getContentPane().setLayout(null);
        		            dialog.getContentPane().setBackground(new Color(255, 255, 255));
        		            dialog.setVisible(true);

        		            JLabel lblNewLabel_1 = new JLabel("Payment");
        		            lblNewLabel_1.setForeground(new Color(214, 0, 36));
        		            lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 20));
        		            lblNewLabel_1.setBounds(219, 11, 124, 36);
        		            dialog.getContentPane().add(lblNewLabel_1);

        		            JLabel amountLabel = new JLabel("Payment Amount: ");
        		            amountLabel.setForeground(new Color(0, 0, 0));
        		            amountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            amountLabel.setBounds(95, 58, 150, 20);
        		            dialog.getContentPane().add(amountLabel);

        		            JLabel currencyLabel = new JLabel("Currency:");
        		            currencyLabel.setForeground(new Color(0, 0, 0));
        		            currencyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            currencyLabel.setBounds(95, 89, 150, 20);
        		            dialog.getContentPane().add(currencyLabel);

        		            JComboBox<String> currency = new JComboBox<String>();
        		            currency.setBounds(255, 89, 200, 20);
        		            dialog.getContentPane().add(currency);
        		            currency.addItem("INR - Indian Rupee");
        		            currency.addItem("USD - US Dollar");
        		            currency.addItem("CAD - Canadian Dollar");

        		            JTextField paymentAmountField = new JTextField();
        		            paymentAmountField.setBounds(255, 58, 200, 20);
        		            paymentAmountField.setText("5000 INR");
        		            dialog.getContentPane().add(paymentAmountField);

        		            currency.addActionListener(new ActionListener() {
        		                public void actionPerformed(ActionEvent e) {
        		                    String selectedCurrency = (String) currency.getSelectedItem();
        		                    if (selectedCurrency.equals("USD - US Dollar")) {
        		                        try {
        		                            String paymentAmountString = paymentAmountField.getText();
        		                            double paymentAmount = Double.parseDouble(paymentAmountString.split(" ")[0]); // Extract the number part of the string
        		                            double convertedAmount = paymentAmount * 0.013; // Conversion rate as of April 2023
        		                            paymentAmountField.setText(String.format("%.2f", convertedAmount) + " USD");
        		                        } catch (NumberFormatException ex) {
        		                            paymentAmountField.setText("Invalid amount entered.");
        		                        }
        		                    } else if (selectedCurrency.equals("CAD - Canadian Dollar")) {
        		                        try {
        		                            String paymentAmountString = paymentAmountField.getText();
        		                            double paymentAmount = Double.parseDouble(paymentAmountString.split(" ")[0]); // Extract the number part of the string
        		                            double convertedAmount = paymentAmount * 0.017; // Conversion rate as of April 2023
        		                            paymentAmountField.setText(String.format("%.2f", convertedAmount) + " CAD");
        		                        } catch (NumberFormatException ex) {
        		                            paymentAmountField.setText("Invalid amount entered.");
        		                        }
        		                    } else if (selectedCurrency.equals("INR - Indian Rupee")) {
        		                        paymentAmountField.setText("5000 INR");
        		                    }
        		                }
        		            });


        		            JLabel paymentMethodsLabel = new JLabel("<html>Preferred methods of <br> payment:");
        		            paymentMethodsLabel.setForeground(new Color(0, 0, 0));
        		            paymentMethodsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        		            paymentMethodsLabel.setBounds(95, 117, 137, 42);
        		            dialog.getContentPane().add(paymentMethodsLabel);

        		            JRadioButton bankChequeButton = new JRadioButton("Master Card");
        		            bankChequeButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            bankChequeButton.setForeground(new Color(0, 0, 0));
        		            bankChequeButton.setBackground(new Color(255, 255, 255));
        		            bankChequeButton.setBounds(255, 120, 124, 20);
        		            dialog.getContentPane().add(bankChequeButton);

        		            JRadioButton visaButton = new JRadioButton("Visa");
        		            visaButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            visaButton.setForeground(new Color(0, 0, 0));
        		            visaButton.setBackground(new Color(255, 255, 255));
        		            visaButton.setBounds(391, 120, 69, 20);
        		            dialog.getContentPane().add(visaButton);

        		            // Add radio buttons to a ButtonGroup
        		            ButtonGroup paymentMethodsGroup = new ButtonGroup();
        				    paymentMethodsGroup.add(bankChequeButton);
        		            paymentMethodsGroup.add(visaButton);

        				JLabel cardNumberLabel = new JLabel("Card Number:");
        		        cardNumberLabel.setForeground(new Color(0, 0, 0));
        		        cardNumberLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        cardNumberLabel.setBounds(95, 173, 150, 20);
        		        dialog.getContentPane().add(cardNumberLabel);

        		        JFormattedTextField amountTextField = new JFormattedTextField();
        		        amountTextField.setBounds(255, 58, 200, 20);
        		        dialog.getContentPane().add(amountTextField);
        		        
        		        JFormattedTextField cardNumberTextField = new JFormattedTextField();
        		        cardNumberTextField.setBounds(255, 173, 200, 20);
        		        dialog.getContentPane().add(cardNumberTextField);

        		        JLabel expiryDateLabel = new JLabel("Expiry Date:");
        		        expiryDateLabel.setForeground(new Color(0, 0, 0));
        		        expiryDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        expiryDateLabel.setBounds(95, 204, 150, 20);
        		        dialog.getContentPane().add(expiryDateLabel);

        		        JFormattedTextField expiryDateTextField = new JFormattedTextField();
        		        expiryDateTextField.setBounds(255, 204, 200, 20);

        		        // Create a SimpleDateFormat object with the desired format
        		        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy");

        		        // Set the format for the JFormattedTextField
        		        expiryDateTextField.setFormatterFactory(new DefaultFormatterFactory(new DateFormatter(dateFormat)));

        		        // Set the initial text to the desired format
        		        expiryDateTextField.setText("MM/YYYY");

        		        // Add a FocusListener to remove the placeholder text when the user clicks on the field
        		        expiryDateTextField.addFocusListener(new FocusListener() {
        		            @Override
        		            public void focusGained(FocusEvent e) {
        		                // Remove the placeholder text when the user clicks on the field
        		                if (expiryDateTextField.getText().equals("MM/YYYY")) {
        		                    expiryDateTextField.setText("");
        		                }
        		            }

        		            @Override
        		            public void focusLost(FocusEvent e) {
        		                // If the field is empty when the user leaves it, reset the placeholder text
        		                if (expiryDateTextField.getText().isEmpty()) {
        		                    expiryDateTextField.setText("MM/YYYY");
        		                }
        		            }
        		        });

        		        dialog.getContentPane().add(expiryDateTextField);
        		        
        		        JLabel cvvLabel = new JLabel("CVV:");
        		        cvvLabel.setForeground(new Color(0, 0, 0));
        		        cvvLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        cvvLabel.setBounds(95, 235, 150, 20);
        		        dialog.getContentPane().add(cvvLabel);

        		        JPasswordField cvvTextField = new JPasswordField();
        		        cvvTextField.setBounds(255, 235, 200, 20);
        		        dialog.getContentPane().add(cvvTextField);

        		        JButton confirmButton = new JButton("Confirm Payment");
        		        confirmButton.addActionListener(new ActionListener() {
        		            public void actionPerformed(ActionEvent e) {
        		                String paymentAmountField = currency.getSelectedItem().toString();
        		                String paymentMethod = "";
        		                if (bankChequeButton.isSelected()) {
        		                    paymentMethod = bankChequeButton.getText();
        		                } else if (visaButton.isSelected()) {
        		                    paymentMethod = visaButton.getText();
        		                   
        		                }

        		                if (cardNumberTextField.getText().isEmpty()) {
        		                    JOptionPane.showMessageDialog(null, "Payment info not filled. Please fill in all the required fields.");
        		                    return;
        		                } else if (!cardNumberTextField.getText().matches("\\d+")) {
        		                    JOptionPane.showMessageDialog(null, "Invalid card number. Only numbers are allowed.");
        		                    return;
        		                } else {
        		                    JOptionPane.showMessageDialog(null, "Payment of " + " " + paymentAmountField
                                            + " using " + paymentMethod + " has been confirmed. You will get all the details mailed to you.");
        		                    }
        		                dialog.dispose();
        		                
        		                HomeLog home = new HomeLog();
    		                    home.setBounds(100, 100, 895, 500);
    		                    home.setVisible(true);
    		                    dispose();
        		                }
        		        });
        		        confirmButton.setBounds(219, 284, 150, 23);
        		        dialog.getContentPane().add(confirmButton); 
        		        }
        		      }
    		       });
        		btnPay.setFont(new Font("Leelawadee UI", Font.BOLD, 14));
        		btnPay.setBackground(new Color(214, 0 ,36));
        		btnPay.setBounds(465, 492, 89, 23);
        		contentPanel1.add(btnPay);
        		
        		JLabel lblIUnderstandThat = new JLabel("<html>I understand that CIC is collecting this personal information to assess whether I should be granted a study permit and will use <br>this information to verify my eligibility for a study permit as well as my compliance with the conditions of my study permit. <br>CIC may disclose my personal information to CBSA to enforce the requirements of the Immigration and Refugee Protection Act.<br><br>I also understand that CIC may disclose my personal information to my designated learning institution to inquire whether I am in<br> compliance with the conditions of my study permit. I consent to the disclosure of my personal information by my designated<br> learning institution to CIC for the purpose of determining whether I am in compliance with these conditions. Failure to provide <br>such consent will result in a refusal to grant a study permit.<br><br>I declare that [have answered all questions in this application fully and truthfully.<br><br></html>");
        		lblIUnderstandThat.setVerticalAlignment(SwingConstants.TOP);
        		lblIUnderstandThat.setForeground(Color.BLACK);
        		lblIUnderstandThat.setFont(new Font("Lucida Bright", Font.BOLD, 12));
        		lblIUnderstandThat.setBackground(Color.BLACK);
        		lblIUnderstandThat.setBounds(10, 259, 849, 168);
        		contentPanel1.add(lblIUnderstandThat);
        		
        		JRadioButton rdbtnNewRadioButton = new JRadioButton("Yes");
        		buttonGroup.add(rdbtnNewRadioButton);
        		rdbtnNewRadioButton.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 12));
        		rdbtnNewRadioButton.setBackground(new Color(242, 242, 242));
        		rdbtnNewRadioButton.setBounds(20, 230, 109, 23);
        		contentPanel1.add(rdbtnNewRadioButton);
        		
        		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("No");
        		buttonGroup.add(rdbtnNewRadioButton_1);
        		rdbtnNewRadioButton_1.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 12));
        		rdbtnNewRadioButton_1.setBackground(new Color(242, 242, 242));
        		rdbtnNewRadioButton_1.setBounds(165, 230, 109, 23);
        		contentPanel1.add(rdbtnNewRadioButton_1);
        		
        		JButton btnNewButton_1 = new JButton("");
        		btnNewButton_1.setBackground(new Color(255, 255, 255));
        		btnNewButton_1.addActionListener(new ActionListener() {
        			public void actionPerformed(ActionEvent e) {
        	        		
        				// Get the current date
        	        		Calendar currentDate = Calendar.getInstance();
        	        		// Format the date in "dd/MM/yyyy" format
        	        		
        	        		String formattedDate = String.format("%1$td/%1$tm/%1$tY", currentDate.getTime());
        	        		// Change the text of the button to today's date
        	        		
        	        		btnNewButton_1.setText(formattedDate);
        	        	}
        	        });
        		btnNewButton_1.setBounds(570, 435, 170, 30);
        		contentPanel1.add(btnNewButton_1);
        		
		contentScrollPane.setBounds(0, 0, 883, 500);
		contentScrollPane.setBackground(new Color(0, 0, 64));
		contentPane.add(contentScrollPane);
		}
}
