package JDBC;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class CreateDatabase {
    public static void main(String[] args) {
        // JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        Connection conn = null;
        Statement stmt = null;

        //Scanner input = new Scanner(System.in);
        //System.out.print("Enter the name of the database: ");
        //String dbName = input.nextLine();
        

        try {
            // Register JDBC driver
            Class.forName(jdbcDriver);

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl, username, password);

            // Execute a query to create a new database
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String sql = "CREATE DATABASE IF NOT EXISTS " + dbName;
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully.");

        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
       
      create_logs(dbName);
    }

    static void create_logs(String dbname) {
      String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        Connection conn = null;
        Statement stmt = null;

        try {
            // Register JDBC driver
            Class.forName(jdbcDriver);

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl, username, password);
            
            String dbName = dbname + "_logs";
            
         // Execute a query to create a new database
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String sql = "CREATE DATABASE IF NOT EXISTS " + dbName;
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully.");

        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }

      
    }
    
}