package JDBC;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class CreateTable {
	static int count = 0;

   public static void main(String[] args) {
	   
	   CreateDatabase.main(null);
	   //String myArg = "hello";
	   String tbName = args[0];
	   String countryCode = args[1];
	   // JDBC driver name and database URL
       String jdbcDriver = "com.mysql.jdbc.Driver";
       String dbUrl = "jdbc:mysql://localhost/";
       String dbName = "VisaProcessingSystem";
       
       File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
       ArrayList<String> lines = new ArrayList<>();

       try {
           Scanner scanner = new Scanner(file);

           while (scanner.hasNextLine()) {
               String line = scanner.nextLine();
               lines.add(line); // Append line to ArrayList
           }

           scanner.close();

       } catch (FileNotFoundException e) {
           e.printStackTrace();
       }

       // Print the lines ArrayList
       //for (String line : lines) {
       //    System.out.println(line);
       //}


       // Database credentials
       String username = lines.get(0);
       String password = lines.get(1);

       Connection conn = null;
       Statement stmt = null;

       //Scanner input = new Scanner(System.in);
       //System.out.print("Enter the name of the database: ");
       //String dbName = input.nextLine();
      
      switch(tbName) {
      case "SecA":
    	  try {
        	  // Register JDBC driver
              Class.forName(jdbcDriver);

              // Open a connection
              System.out.println("Connecting to database...");
              conn = DriverManager.getConnection(dbUrl+dbName, username, password);

             // Execute a query
             stmt = conn.createStatement();
             String sql = "CREATE TABLE IF NOT EXISTS " + tbName + "_" + countryCode +
                          "(ID INTEGER not NULL, " +
                          " Name VARCHAR(255), " +
                          " LastName VARCHAR(255), " +
                          " FirstName VARCHAR(255), " +
                          " DOB DATE, " +
                          " TownCity VARCHAR(255), " +
                          " Country VARCHAR(255), " +
                          " PassportNO INTEGER, " +
                          " Passport_EXP DATE, " +
                          " Citizenship VARCHAR(255), " +
                          " PRIMARY KEY ( ID ))";
             stmt.executeUpdate(sql);
             System.out.println("Table created successfully...");
          } catch (SQLException se) {
             // Handle errors for JDBC
             se.printStackTrace();
          } catch (Exception e) {
             // Handle errors for Class.forName
             e.printStackTrace();
          } finally {
             // finally block used to close resources
             try {
                if (stmt != null)
                   conn.close();
             } catch (SQLException se) {
             } // do nothing
             try {
                if (conn != null)
                   conn.close();
             } catch (SQLException se) {
                se.printStackTrace();
             } // end finally try
          } // end try
    	  break;
        
      case "SecB":
    	  try {
          	// Register JDBC driver
                Class.forName(jdbcDriver);

                // Open a connection
                System.out.println("Connecting to database...");
                conn = DriverManager.getConnection(dbUrl+dbName, username, password);

               // Execute a query
               stmt = conn.createStatement();
               String sql = "CREATE TABLE IF NOT EXISTS " + tbName + "_" + countryCode +
                            "(ID INTEGER not NULL, " +
                            " ResidentialADD VARCHAR(255), " +
                            " Telephone VARCHAR(255), " +
                            " LastName VARCHAR(255), " +
                            " FirstName VARCHAR(255), " +
                            " Telephone_NO VARCHAR(255), " +
                            " Email VARCHAR(255), " +
                            " PRIMARY KEY ( ID ))";
               stmt.executeUpdate(sql);
               System.out.println("Table created successfully...");
            } catch (SQLException se) {
               // Handle errors for JDBC
               se.printStackTrace();
            } catch (Exception e) {
               // Handle errors for Class.forName
               e.printStackTrace();
            } finally {
               // finally block used to close resources
               try {
                  if (stmt != null)
                     conn.close();
               } catch (SQLException se) {
               } // do nothing
               try {
                  if (conn != null)
                     conn.close();
               } catch (SQLException se) {
                  se.printStackTrace();
               } // end finally try
            } // end try
    	  break;
      case "SecD" :
    	  try {
          	// Register JDBC driver
                Class.forName(jdbcDriver);

                // Open a connection
                System.out.println("Connecting to database...");
                conn = DriverManager.getConnection(dbUrl+dbName, username, password);

               // Execute a query
               stmt = conn.createStatement();
               String sql = "CREATE TABLE IF NOT EXISTS " + tbName + "_" + countryCode +
                            "(ID INTEGER not NULL, " +
                            " Signature VARCHAR(255), " +
                            " Date DATE, " +
                            " PRIMARY KEY ( ID ))";
               stmt.executeUpdate(sql);
               System.out.println("Table created successfully...");
            } catch (SQLException se) {
               // Handle errors for JDBC
               se.printStackTrace();
            } catch (Exception e) {
               // Handle errors for Class.forName
               e.printStackTrace();
            } finally {
               // finally block used to close resources
               try {
                  if (stmt != null)
                     conn.close();
               } catch (SQLException se) {
               } // do nothing
               try {
                  if (conn != null)
                     conn.close();
               } catch (SQLException se) {
                  se.printStackTrace();
               } // end finally try
            } // end try
    	  break;
      } 
      
   
   }
    public void Create_UserData(String uName,String uPassword,String uEmail,String uCPassword) {
    	
    	if (uPassword == uCPassword) //get it from text feild
    	{
    		   String jdbcDriver = "com.mysql.jdbc.Driver";
    	       String dbUrl = "jdbc:mysql://localhost/";
    	       String dbName = "VisaProcessingSystem";
    	       String tbName = "VPS_UserData";
    	       
    	       CreateDatabase.main(null);
    	       File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
    	       ArrayList<String> lines = new ArrayList<>();

    	       try {
    	           Scanner scanner = new Scanner(file);

    	           while (scanner.hasNextLine()) {
    	               String line = scanner.nextLine();
    	               lines.add(line); // Append line to ArrayList
    	           }

    	           scanner.close();

    	       } catch (FileNotFoundException e) {
    	           e.printStackTrace();
    	       }
    	    // Database credentials
    	       String username = lines.get(0);
    	       String password = lines.get(1);

    	       Connection conn = null;
    	       Statement stmt = null;
    	       try {
    	        	  // Register JDBC driver
    	              Class.forName(jdbcDriver);

    	              // Open a connection
    	              System.out.println("Connecting to database...");
    	              conn = DriverManager.getConnection(dbUrl+dbName, username, password);

    	             // Execute a query
    	             stmt = conn.createStatement();
    	             String sql = "CREATE TABLE IF NOT EXISTS " + tbName + 
    	                          "(ID INTEGER not NULL, " +
    	                          " Name VARCHAR(255), " +
    	                          " Email VARCHAR(255), " +
    	                          " Password VARCHAR(255), " +
    	                          " PRIMARY KEY ( ID ))";
    	             stmt.executeUpdate(sql);
    	             System.out.println("Table created successfully...");
    	          } catch (SQLException se) {
    	             // Handle errors for JDBC
    	             se.printStackTrace();
    	          } catch (Exception e) {
    	             // Handle errors for Class.forName
    	             e.printStackTrace();
    	          } finally {
    	             // finally block used to close resources
    	             try {
    	                if (stmt != null)
    	                   conn.close();
    	             } catch (SQLException se) {
    	             } // do nothing
    	             try {
    	                if (conn != null)
    	                   conn.close();
    	             } catch (SQLException se) {
    	                se.printStackTrace();
    	             } // end finally try
    	          } // end try
    	       count++;
    	       InsertData.insertUserData(conn, tbName, count, uName, uEmail, uPassword); //name mail pass get from text field
    	}
   }
}
