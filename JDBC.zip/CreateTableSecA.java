package JDBC;
//import VSP.CreateTable;

public class CreateTableSecA {
	public static void main(String[] args) {
    String arg1 = "SecA";
    String arg2 = "US";
    CreateTable.main(new String[]{arg1, arg2});
	}
}
