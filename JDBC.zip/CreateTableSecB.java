package JDBC;
//import VSP.CreateTable;

public class CreateTableSecB {
	public static void main(String[] args) {
    String arg1 = "SecB";
    String arg2 = "US";
    CreateTable.main(new String[]{arg1, arg2});
	}
}
