package JDBC;
//import VSP.CreateTable;

public class CreateTableSecD {
	public static void main(String[] args) {
    String arg1 = "SecD";
    String arg2 = "US";
    CreateTable.main(new String[]{arg1, arg2});
	}
}
