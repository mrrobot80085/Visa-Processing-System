package JDBC;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.Statement;

public class DataReturn {
	public static void main(String[] args) {
		 String tbName = args[0];
	     String countryCode = args[1];
	
        // establish a connection to MySQL database
    	// JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("C:\\Users\\Public\\New\\src\\VSP\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        Connection conn = null;
        switch(tbName) {
        //SECA
        case "SecA":
	        try {
	            // Open a connection
	            System.out.println("Connecting to database...");
	            conn = DriverManager.getConnection(dbUrl+dbName, username, password);
	            // create the table if it doesn't exist
	            CreateTable.main(new String[]{tbName, countryCode});
	            InsertData.insertDataA(conn, tbName, countryCode, 1, "Name", "LName", "FNAme", "2022-03-22", "MUM", "IND", 1, "2022-05-10", "IND");
	            String query = "SELECT * FROM " + tbName + "_" + countryCode;
	            Statement stmt = conn.createStatement();
	            ResultSet rs = stmt.executeQuery(query);
	            
	            // print out the retrieved data
	            while (rs.next()) {
	                System.out.println(rs.getInt("ID") + ", " + rs.getString("Name") + ", " + rs.getString("LastName") + ", " +
	                                   rs.getString("FirstName") + ", " + rs.getDate("DOB") + ", " + rs.getString("TownCity") + ", " +
	                                   rs.getString("Country") + ", " + rs.getInt("PassportNO") + ", " + rs.getDate("Passport_EXP") + ", " +
	                                   rs.getString("Citizenship"));
	            }
	        
	    } catch (SQLException ex) {
	        System.out.println("Error: " + ex.getMessage());
	    } finally {
	        // close the connection to MySQL database
	        try {
	            if (conn != null) {
	                conn.close();
	            }
	        } catch (SQLException ex) {
	            System.out.println("Error: " + ex.getMessage());
	        }
	    }
	        break;
	        
       
    //SECB
    case "SecB":      
        try {
            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl+dbName, username, password);
            // create the table if it doesn't exist
            CreateTable.main(new String[]{tbName, countryCode});
            InsertData.insertDataB(conn, tbName, countryCode, 1, "ResidentialADD", "Telephone", "lastName", "firstName", "Telephone_NO", "Email");
            String query = "SELECT * FROM " + tbName + "_" + countryCode;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            // print out the retrieved data
            while (rs.next()) {
                System.out.println(rs.getInt("ID") + ", " + rs.getString("ResidentialADD") + ", " + rs.getString("Telephone") + ", " +
                                   rs.getString("lastName") + ", " + rs.getString("firstName") + ", " + rs.getString("Telephone_NO") + ", " +
                                   rs.getString("Email"));
            }
        
    } catch (SQLException ex) {
        System.out.println("Error: " + ex.getMessage());
    } finally {
        // close the connection to MySQL database
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
        break;
        
        
   //SECD
    case "SecD":
        try {
            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl+dbName, username, password);
            // create the table if it doesn't exist
            CreateTable.main(new String[]{tbName, countryCode});
            InsertData.insertDataD(conn, tbName, countryCode, 1, "Signature", "2022-03-31");
            String query = "SELECT * FROM " + tbName + "_" + countryCode;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            // print out the retrieved data
            while (rs.next()) {
                System.out.println(rs.getInt("ID") + ", " + rs.getString("Signature") + ", " + rs.getString("Date"));
            }
        
    } catch (SQLException ex) {System.out.println("Error: " + ex.getMessage());}
        finally {
        // close the connection to MySQL database
        try {
            if (conn != null) {conn.close();}
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
        break;
   }
    	
//
}
}
