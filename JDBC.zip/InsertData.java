package JDBC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertData {
	public static void insertDataA(Connection conn, String tbName, String countryCode,
            int id, String name, String lastName, String firstName, String dob,
            String townCity, String country, int passportNo, String passport_Exp, String citizenship) {
			try {
				String query = "INSERT INTO " + tbName + "_" + countryCode + " (ID, Name, LastName, FirstName, DOB, `TownCity`, Country, PassportNO, Passport_EXP, Citizenship) " +
				     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setInt(1, id);
				stmt.setString(2, name);
				stmt.setString(3, lastName);
				stmt.setString(4, firstName);
				stmt.setString(5, dob);
				stmt.setString(6, townCity);
				stmt.setString(7, country);
				stmt.setInt(8, passportNo);
				stmt.setString(9, passport_Exp);
				stmt.setString(10, citizenship);

				stmt.executeUpdate();
				System.out.println("Data inserted successfully!");
				} catch (SQLException ex) {
				System.out.println("Error: " + ex.getMessage());
				}
}

	public static void insertDataB(Connection conn, String tbName, String countryCode,
            int id, String ResidentialADD,String Telephone, String lastName, String firstName, String Telephone_NO,
            String Email) {
		try {
			String query = "INSERT INTO " + tbName + "_" + countryCode + " (ID, ResidentialADD, Telephone, LastName, FirstName, Telephone_NO, Email) " +
			     "VALUES (?, ?, ?, ?, ?, ?, ?)";

			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, id);
			stmt.setString(2, ResidentialADD);
			stmt.setString(3, Telephone);
			stmt.setString(4, lastName);
			stmt.setString(5, firstName);
			stmt.setString(6, Telephone_NO);
			stmt.setString(7, Email);

			stmt.executeUpdate();
			System.out.println("Data inserted successfully!");
			} catch (SQLException ex) {
			System.out.println("Error: " + ex.getMessage());
			}
	}
	public static void insertDataD(Connection conn, String tbName, String countryCode,
            int id, String Signature, String Date) {
		try {
			String query = "INSERT INTO " + tbName + "_" + countryCode + " (ID, Signature, Date) " +
			     "VALUES (?, ?, ?)";

			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, id);
			stmt.setString(2, Signature);
			stmt.setString(3, Date);

			stmt.executeUpdate();
			System.out.println("Data inserted successfully!");
			} catch (SQLException ex) {
			System.out.println("Error: " + ex.getMessage());
			}
	}
	public static void insertUserData(Connection conn, String tbName,
            int id, String uName, String uEmail, String uPassword) {
		try {
			String query = "INSERT INTO " + tbName +  " (ID, uName, uEmail, uPassword) " +
			     "VALUES (?, ?, ?, ?)";

			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, id);
			stmt.setString(2, uName);
			stmt.setString(3, uEmail);
			stmt.setString(4, uPassword);

			stmt.executeUpdate();
			System.out.println("Data inserted successfully!");
			} catch (SQLException ex) {
			System.out.println("Error: " + ex.getMessage());
			}
	}

}
