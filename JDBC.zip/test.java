package JDBC;
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreateDatabase.main(null);
		CreateTableSecA.main(null);
		CreateTableSecB.main(null);
		CreateTableSecD.main(null);
		String arg1 = "SecD";
	    String arg2 = "US";
	    DataReturn.main(new String[]{arg1, arg2});

	}

}
