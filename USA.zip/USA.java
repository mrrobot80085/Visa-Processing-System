package USA;

import java.awt.EventQueue;
import VisaGUI.Student;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;

import JDBC.CreateDatabase;
import JDBC.CreateTable;
import com.toedter.calendar.JCalendar;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JDialog;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;

public class USA extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_4;
    private JTextField textField_5;
    private JTextField textField_6;
    private JTextField textField_7;
    private JTextField textField_8;
    private JTextField textField_9;
    private JTextField textField_10;
    private final ButtonGroup buttonGroup = new ButtonGroup();
    private final ButtonGroup buttonGroup_1 = new ButtonGroup();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    USA frame = new USA();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public void insertDataUSAA(String tbName, String countryCode,
            int id, String name, String lastName, String firstName, String dob,
            String townCity, String country, String passportNo, String passport_Exp, String citizenship) {
    	 String dbUrl = "jdbc:mysql://localhost/";
	     String dbName = "VisaProcessingSystem";
    	 String jdbcUrl = dbUrl + dbName;
    	 File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
	       ArrayList<String> lines = new ArrayList<>();

	       try {
	           Scanner scanner = new Scanner(file);

	           while (scanner.hasNextLine()) {
	               String line = scanner.nextLine();
	               lines.add(line); // Append line to ArrayList
	           }

	           scanner.close();

	       } catch (FileNotFoundException e) {
	           e.printStackTrace();
	       }
	    // Database credentials
	       String username = lines.get(0);
	       String password = lines.get(1);
	       String p1 = "INSERT INTO SecA_";
	       String p2 = "_USA (ID, Name, LastName, FirstName, DOB, TownCity, Country, PassportNO, Passport_Exp, Citizenship) " ;
	       String p3 = "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

         try (Connection conn = DriverManager.getConnection(jdbcUrl, username, password)) {
             String sql = p1 + tbName + p2 + p3;
             PreparedStatement stmt = conn.prepareStatement(sql);
             stmt.setInt(1, id);
			 stmt.setString(2, name);
			 stmt.setString(3, lastName);
			 stmt.setString(4, firstName);
			 stmt.setString(5, dob);
			 stmt.setString(6, townCity);
		   	 stmt.setString(7, country);
			 stmt.setString(8, passportNo);
			 stmt.setString(9, passport_Exp);
			 stmt.setString(10, citizenship);
             int rowsAffected = stmt.executeUpdate();
             System.out.println(rowsAffected + " rows inserted");
         } catch (SQLException e) {
             System.out.println("Error: " + e.getMessage());
         }
    }
    
    public static void insertDataA(String tbName, String countryCode,
            int id, String name, String lastName, String firstName, String dob,
            String townCity, String country, String passportNo, String passport_Exp, String citizenship) {
    	   String jdbcDriver = "com.mysql.jdbc.Driver";
	       String dbUrl = "jdbc:mysql://localhost/";
	       String dbName = "VisaProcessingSystem";
	       String tb_Name = "VPS_UserData";
	       //System.out.println(passport_Exp);
	       
	       CreateDatabase.main(null);
	       File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
	       ArrayList<String> lines = new ArrayList<>();

	       try {
	           Scanner scanner = new Scanner(file);

	           while (scanner.hasNextLine()) {
	               String line = scanner.nextLine();
	               lines.add(line); // Append line to ArrayList
	           }

	           scanner.close();

	       } catch (FileNotFoundException e) {
	           e.printStackTrace();
	       }
	    // Database credentials
	       String username = lines.get(0);
	       String password = lines.get(1);

	       Connection conn = null;
	       //Statement stmt = null;
	       String p1 = "INSERT INTO SecA_";
	       String p2 = "_USA(ID, Name, LastName, FirstName, DOB, TownCity, Country, PassportNO, Passport_EXP, Citizenship) " ;
	       String p3 = "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	       
    	
			try {
				//Class.forName(jdbcDriver);

	              // Open a connection
	              System.out.println("Connecting to database...");
	              conn = DriverManager.getConnection(dbUrl+dbName, username, password);
	              
				  String query = "INSERT INTO SecA_" + tbName + "_USA (ID, Name, LastName, FirstName, DOB, TownCity, Country, PassportNO, Passport_EXP, Citizenship) " +
				     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setInt(1, id);
				stmt.setString(2, name);
				stmt.setString(3, lastName);
				stmt.setString(4, firstName);
				stmt.setString(5, dob);
				stmt.setString(6, townCity);
				stmt.setString(7, country);
				stmt.setString(8, passportNo);
				stmt.setString(9, passport_Exp);
				stmt.setString(10, citizenship);

				stmt.executeUpdate();
				System.out.println("Data inserted successfully!");
				} catch (SQLException se) {
		            // Handle errors for JDBC
		            se.printStackTrace();
		        } catch (Exception e) {
		            // Handle errors for Class.forName
		            e.printStackTrace();
		        } finally {
		            // Close resources
		            try {
		                if (conn != null)
		                    conn.close();
		            } catch (SQLException se) {
		                se.printStackTrace();
		            }
		        }
}
    public String readFile() {
    	 String fileName = "file.txt";
         Path path = Paths.get(fileName);
         try {
             String fileContents = Files.readString(path);
             System.out.println(fileContents);
             return fileContents;
         } catch (IOException e) {
             System.out.println("An error occurred while reading the file.");
             e.printStackTrace();
             return null;
         }
    }
    public static int stringToInt(String str) {
        try {
            int num = Integer.parseInt(str);
            return num;
        } catch (NumberFormatException e) {
            System.out.println("The string is not a valid integer.");
            e.printStackTrace();
            return 0; // Or any other default value that you choose
        }
    }
    public static ArrayList<String> readAndCleanFile(String filePath) {
        File file = new File(filePath);
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().replaceAll("\\s+", "");
                lines.add(line);
                System.out.println(line);
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return lines;
    }
    public int getLastInsertedID(String tbName) {
    	// JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        //Connection conn = null;
        //Statement stmt = null;
        int id = 0;
        try {
        	Connection conn = DriverManager.getConnection(dbUrl+dbName, username, password);
            String query = "SELECT ID FROM " + tbName + " ORDER BY ID DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                id = rs.getInt("ID");
            }
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return id;
    }
public String returnData(String tmp) {
	return tmp;
}
    /**
     * Create the frame.
     */
    public USA() {
    	setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 895, 800);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        // Set the content pane
        setContentPane(contentPane);
        
        // Create the scroll pane and the content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(new Color(240, 240, 240));
        contentPanel.setPreferredSize(new Dimension(873, 730));
        contentPanel.setLayout(null);

        JScrollPane contentScrollPane = new JScrollPane(contentPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contentScrollPane.setBounds(0, 0, 883, 500);
        contentScrollPane.setBackground(new Color(0, 0, 64));
        
        contentPane.add(contentScrollPane);
        
        JPanel contentPane_1 = new JPanel();
        contentPane_1.setLayout(null);
        contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane_1.setBackground(new Color(250, 250, 250));
        contentPane_1.setBounds(0, 0, 863, 1000);
        contentPanel.add(contentPane_1);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(0, 0, 64));
        panel_1.setLayout(null);
        panel_1.setBounds(0, 56, 878, 32);
        contentPane_1.add(panel_1);
        
        JLabel lblNewLabel_2 = new JLabel("Section-A");
        lblNewLabel_2.setForeground(new Color(255, 255, 255));
        lblNewLabel_2.setBackground(new Color(255, 255, 255));
        lblNewLabel_2.setFont(new Font("Castellar", Font.BOLD, 25));
        lblNewLabel_2.setBounds(10, 0, 176, 32);
        panel_1.add(lblNewLabel_2);
        
        JLabel lblNewLabel_1_1 = new JLabel("UNITED STATES OF AMERICA");
        lblNewLabel_1_1.setForeground(new Color(0, 0, 64));
        lblNewLabel_1_1.setFont(new Font("Castellar", Font.BOLD, 33));
        lblNewLabel_1_1.setBounds(5, 5, 639, 54);
        contentPane_1.add(lblNewLabel_1_1);
        
        JLabel nameLabel_1 = new JLabel("Name as shown in passport");
        nameLabel_1.setBackground(new Color(255, 255, 255));
        nameLabel_1.setForeground(new Color(0, 0, 0));
        nameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        nameLabel_1.setBounds(80, 105, 300, 30);
        contentPane_1.add(nameLabel_1);
        
        textField = new JTextField();
        textField.setBackground(new Color(255, 255, 255));
        textField.setForeground(new Color(0, 0, 0));
        textField.setBounds(380, 105, 300, 30);
        contentPane_1.add(textField);
        
        JLabel familyNameLabel_1 = new JLabel("Family/last name");
        familyNameLabel_1.setBackground(new Color(255, 255, 255));
        familyNameLabel_1.setForeground(new Color(0, 0, 0));
        familyNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        familyNameLabel_1.setBounds(80, 145, 300, 30);
        contentPane_1.add(familyNameLabel_1);
        
        textField_1 = new JTextField();
        textField_1.setBackground(new Color(255, 255, 255));
        textField_1.setForeground(new Color(0, 0, 0));
        textField_1.setBounds(380, 145, 300, 30);
        contentPane_1.add(textField_1);
        
        JLabel givenNameLabel_1 = new JLabel("Given/first name(s)");
        givenNameLabel_1.setBackground(new Color(255, 255, 255));
        givenNameLabel_1.setForeground(new Color(0, 0, 0));
        givenNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        givenNameLabel_1.setBounds(80, 185, 300, 30);
        contentPane_1.add(givenNameLabel_1);
        
        textField_2 = new JTextField();
        textField_2.setBackground(new Color(255, 255, 255));
        textField_2.setForeground(new Color(0, 0, 0));
        textField_2.setBounds(380, 185, 300, 30);
        contentPane_1.add(textField_2);
        
        JLabel titleLabel_1 = new JLabel("Preferred title");
        titleLabel_1.setBackground(new Color(255, 255, 255));
        titleLabel_1.setForeground(new Color(0, 0, 0));
        titleLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        titleLabel_1.setBounds(80, 225, 300, 30);
        contentPane_1.add(titleLabel_1);
        
        JRadioButton rdbtnMr = new JRadioButton("Mr.");
        buttonGroup.add(rdbtnMr);
        rdbtnMr.setBackground(new Color(250, 250, 250));
        rdbtnMr.setForeground(new Color(0, 0, 0));
        rdbtnMr.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnMr.setBounds(380, 230, 41, 23);
        contentPane_1.add(rdbtnMr);

        JRadioButton rdbtnMrs = new JRadioButton("Mrs.");
        buttonGroup.add(rdbtnMrs);
        rdbtnMrs.setBackground(new Color(250, 250, 250));
        rdbtnMrs.setForeground(new Color(0, 0, 0));
        rdbtnMrs.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnMrs.setBounds(428, 230, 56, 23);
        contentPane_1.add(rdbtnMrs);

        JRadioButton rdbtnMs = new JRadioButton("Ms.");
        buttonGroup.add(rdbtnMs);
        rdbtnMs.setBackground(new Color(250, 250, 250));
        rdbtnMs.setForeground(new Color(0, 0, 0));
        rdbtnMs.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnMs.setBounds(496, 230, 49, 23);
        contentPane_1.add(rdbtnMs);

        JRadioButton rdbtnMiss = new JRadioButton("Miss");
        buttonGroup.add(rdbtnMiss);
        rdbtnMiss.setBackground(new Color(250, 250, 250));
        rdbtnMiss.setForeground(new Color(0, 0, 0));
        rdbtnMiss.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnMiss.setBounds(555, 230, 56, 23);
        contentPane_1.add(rdbtnMiss);
        
        JLabel genderLabel_1 = new JLabel("Gender");
        genderLabel_1.setBackground(new Color(255, 255, 255));
        genderLabel_1.setForeground(new Color(0, 0, 0));
        genderLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        genderLabel_1.setBounds(80, 265, 300, 30);
        contentPane_1.add(genderLabel_1);
        
        JRadioButton rdbtnMale = new JRadioButton("Male");
        buttonGroup_1.add(rdbtnMale);
        rdbtnMale.setBackground(new Color(250, 250, 250));
        rdbtnMale.setForeground(new Color(0, 0, 0));
        rdbtnMale.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnMale.setBounds(380, 269, 56, 23);
        contentPane_1.add(rdbtnMale);

        JRadioButton rdbtnFemale = new JRadioButton("Female");
        buttonGroup_1.add(rdbtnFemale);
        rdbtnFemale.setBackground(new Color(250, 250, 250));
        rdbtnFemale.setForeground(new Color(0, 0, 0));
        rdbtnFemale.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnFemale.setBounds(447, 270, 69, 23);
        contentPane_1.add(rdbtnFemale);
        
        JLabel dobLabel_1 = new JLabel("Date of birth");
        dobLabel_1.setBackground(new Color(255, 255, 255));
        dobLabel_1.setForeground(new Color(0, 0, 0));
        dobLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        dobLabel_1.setBounds(80, 305, 300, 30);
        contentPane_1.add(dobLabel_1);
        
        JLabel birthplaceLabel_1 = new JLabel("Town/city of birth");
        birthplaceLabel_1.setBackground(new Color(255, 255, 255));
        birthplaceLabel_1.setForeground(new Color(0, 0, 0));
        birthplaceLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        birthplaceLabel_1.setBounds(80, 345, 300, 30);
        contentPane_1.add(birthplaceLabel_1);
        
        textField_4 = new JTextField();
        textField_4.setBackground(new Color(255, 255, 255));
        textField_4.setForeground(new Color(0, 0, 0));
        textField_4.setBounds(380, 345, 300, 30);
        contentPane_1.add(textField_4);
        
        JLabel birthCountryLabel_1 = new JLabel("Country/region of birth");
        birthCountryLabel_1.setBackground(new Color(255, 255, 255));
        birthCountryLabel_1.setForeground(new Color(0, 0, 0));
        birthCountryLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        birthCountryLabel_1.setBounds(80, 385, 300, 30);
        contentPane_1.add(birthCountryLabel_1);
        
        textField_5 = new JTextField();
        textField_5.setBackground(new Color(255, 255, 255));
        textField_5.setForeground(new Color(0, 0, 0));
        textField_5.setBounds(380, 385, 300, 30);
        contentPane_1.add(textField_5);
        
        JLabel passportNumLabel_1 = new JLabel("Passport number");
        passportNumLabel_1.setBackground(new Color(255, 255, 255));
        passportNumLabel_1.setForeground(new Color(0, 0, 0));
        passportNumLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        passportNumLabel_1.setBounds(80, 425, 300, 30);
        contentPane_1.add(passportNumLabel_1);
        
        textField_6 = new JTextField();
        textField_6.setBackground(new Color(255, 255, 255));
        textField_6.setForeground(new Color(0, 0, 0));
        textField_6.setBounds(380, 425, 300, 30);
        contentPane_1.add(textField_6);
        
        JLabel expiryDateLabel_1 = new JLabel("Passport expiration date");
        expiryDateLabel_1.setBackground(new Color(255, 255, 255));
        expiryDateLabel_1.setForeground(new Color(0, 0, 0));
        expiryDateLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        expiryDateLabel_1.setBounds(80, 465, 300, 30);
        contentPane_1.add(expiryDateLabel_1);
        
        textField_7 = new JTextField();
        textField_7.setBackground(new Color(255, 255, 255));
        textField_7.setForeground(new Color(0, 0, 0));
        textField_7.setBounds(380, 465, 300, 30);
        contentPane_1.add(textField_7);
        
        JLabel countryLabel_1 = new JLabel("Country/region where you live");
        countryLabel_1.setBackground(new Color(255, 255, 255));
        countryLabel_1.setForeground(new Color(0, 0, 0));
        countryLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        countryLabel_1.setBounds(80, 505, 300, 30);
        contentPane_1.add(countryLabel_1);
        
        textField_8 = new JTextField();
        textField_8.setBackground(new Color(255, 255, 255));
        textField_8.setForeground(new Color(0, 0, 0));
        textField_8.setBounds(380, 505, 300, 30);
        contentPane_1.add(textField_8);
        
        JLabel citizenshipLabel_1 = new JLabel("Citizenship");
        citizenshipLabel_1.setBackground(new Color(255, 255, 255));
        citizenshipLabel_1.setForeground(new Color(0, 0, 0));
        citizenshipLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        citizenshipLabel_1.setBounds(80, 545, 300, 30);
        contentPane_1.add(citizenshipLabel_1);
        
        textField_9 = new JTextField();
        textField_9.setBackground(new Color(255, 255, 255));
        textField_9.setForeground(new Color(0, 0, 0));
        textField_9.setBounds(380, 545, 300, 30);
        contentPane_1.add(textField_9);
        
        JLabel otherCitizenshipLabel_1 = new JLabel("Other citizenship/nationality");
        otherCitizenshipLabel_1.setBackground(new Color(255, 255, 255));
        otherCitizenshipLabel_1.setForeground(new Color(0, 0, 0));
        otherCitizenshipLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        otherCitizenshipLabel_1.setBounds(80, 585, 300, 30);
        contentPane_1.add(otherCitizenshipLabel_1);
        
        textField_10 = new JTextField();
        textField_10.setBounds(380, 585, 300, 30);
        contentPane_1.add(textField_10);
        
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.setBackground(new Color(192, 192, 192));
        btnNewButton_1.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnNewButton_1.setBounds(242, 645, 105, 30);
        btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student stud = new Student();
				stud.setVisible(true);
				stud.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		});
        contentPane_1.add(btnNewButton_1);
        //
        JButton btnNewButton = new JButton("");
        btnNewButton.setBackground(new Color(255, 255, 255));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	    JDialog dialog = new JDialog(USA.this, "Select Date", true);
        	    JPanel panel = new JPanel();
        	    JCalendar calendar = new JCalendar();
        	    calendar.setTodayButtonVisible(true);
        	    calendar.setNullDateButtonVisible(true); // allow selection of today's date
        	    panel.add(calendar);
        	    JButton okButton = new JButton("OK");
        	    okButton.addActionListener(new ActionListener() {
        	    	public void actionPerformed(ActionEvent e) {
        	    	    try {
        	    	        // Get the selected date from the calendar
        	    	        Calendar selectedDate = calendar.getCalendar();
        	    	        if (selectedDate != null) {
        	    	            int year = selectedDate.get(Calendar.YEAR);
        	    	            if (year > 2010) {
        	    	                throw new Exception("Selected year is not allowed.");
        	    	            }
        	    	            // Format the date in "MM/dd/yyyy" format
        	    	            String formattedDate = String.format("%1$tm/%1$td/%1$tY", selectedDate.getTime());
        	    	            // Change the text of the button to the selected date
        	    	            btnNewButton.setText(formattedDate);
        	    	        }
        	    	        dialog.dispose();
        	    	    } catch (Exception ex) {
        	    	        JOptionPane.showMessageDialog(dialog, ex.getMessage());
        	    	    }
        	    	}
        	    });
        	    panel.add(okButton);
        	    dialog.getContentPane().add(panel);
        	    dialog.pack();
        	    dialog.setLocationRelativeTo(USA.this);
        	    dialog.setVisible(true);
        	}
        });
        btnNewButton.setBounds(380, 306, 300, 30);
        contentPane_1.add(btnNewButton);
        //
        JButton btnNext_1 = new JButton("Next");
        btnNext_1.setForeground(new Color(255, 255, 255));
        btnNext_1.setBackground(new Color(0, 0, 64));
        btnNext_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty()) {
		            JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
		        } else {
		        	//String fileName = "file.txt";
		        	//String fileContent = readFileAndPrint(fileName);
		        	ArrayList<String> tbName = readAndCleanFile("file.txt");
		        	System.out.println(tbName.get(0));
		        	int Id = getLastInsertedID("SecA_"+tbName.get(0)+"_USA") + 1;
		        	//String tb_Name = ;
		        	String NameonPassP =textField.getText();
		        	String fName = textField_2.getText();
		        	String lName = textField_1.getText();
		        	String DOB = btnNewButton.getText();
		        	String townCity = textField_4.getText();
		        	String country = textField_5.getText();
		        	String passNumber = textField_6.getText();
		        	String passEXP = textField_7.getText();
		        	String citizenShip = textField_9.getText();
		            //int pass_num = stringToInt(passNumber);
		        	//System.out.println(tbName);
		        	insertDataA(tbName.get(0),"USA",Id,NameonPassP,lName,fName,DOB,townCity,country,passNumber,passEXP,citizenShip);
		        	USAB usb = new USAB();
		        	usb.setVisible(true);
					usb.setBounds(100, 100, 895, 500);
					dispose();
		        }
			}
        });
        btnNext_1.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnNext_1.setBounds(440, 645, 105, 30);
     
        contentPane_1.add(btnNext_1);
        
        contentScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        contentPane.setLayout(null);
        contentPane.add(contentScrollPane);
        
        // Set window properties
        setTitle("USA Visa Application Form");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(895, 887);
        setVisible(true);
    }
}