package USA;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import JDBC.CreateDatabase;

import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

public class USAB extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					USAB frame = new USAB();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void insertDataB(String tbName,
            int id, String ResidentialADD,String Telephone, String lastName, String firstName, String Telephone_NO,
            String Email) {
		   String jdbcDriver = "com.mysql.jdbc.Driver";
	       String dbUrl = "jdbc:mysql://localhost/";
	       String dbName = "VisaProcessingSystem";
	       String tb_Name = "VPS_UserData";
	       //System.out.println(passport_Exp);
	       
	       CreateDatabase.main(null);
	       File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
	       ArrayList<String> lines = new ArrayList<>();

	       try {
	           Scanner scanner = new Scanner(file);

	           while (scanner.hasNextLine()) {
	               String line = scanner.nextLine();
	               lines.add(line); // Append line to ArrayList
	           }

	           scanner.close();

	       } catch (FileNotFoundException e) {
	           e.printStackTrace();
	       }
	    // Database credentials
	       String username = lines.get(0);
	       String password = lines.get(1);

	       Connection conn = null;
		try {
			System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl+dbName, username, password);
			
			String query = "INSERT INTO SecB_" + tbName + "_" + "USA" + " (ID, ResidentialADD, Telephone, LastName, FirstName, Telephone_NO, Email) " +
			     "VALUES (?, ?, ?, ?, ?, ?, ?)";

			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, id);
			stmt.setString(2, ResidentialADD);
			stmt.setString(3, Telephone);
			stmt.setString(4, lastName);
			stmt.setString(5, firstName);
			stmt.setString(6, Telephone_NO);
			stmt.setString(7, Email);

			stmt.executeUpdate();
			System.out.println("Data inserted successfully!");
			} catch (SQLException ex) {
			System.out.println("Error: " + ex.getMessage());
			}catch (Exception e) {
	            // Handle errors for Class.forName
	            e.printStackTrace();
	        } finally {
	            // Close resources
	            try {
	                if (conn != null)
	                    conn.close();
	            } catch (SQLException se) {
	                se.printStackTrace();
	            }
	        }
	}
	public int getLastInsertedID(String tbName) {
    	// JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        //Connection conn = null;
        //Statement stmt = null;
        int id = 0;
        try {
        	Connection conn = DriverManager.getConnection(dbUrl+dbName, username, password);
            String query = "SELECT ID FROM " + tbName + " ORDER BY ID DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                id = rs.getInt("ID");
            }
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return id;
    }
	
	public static ArrayList<String> readAndCleanFile(String filePath) {
        File file = new File(filePath);
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().replaceAll("\\s+", "");
                lines.add(line);
                System.out.println(line);
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return lines;
    }

	/**
	 * Create the frame.
	 */
	public USAB() {
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 895, 891);
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(250, 250, 250));
	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	    setContentPane(contentPane);
	    // Set the content pane layout to null for absolute positioning
	    contentPane.setLayout(null);
	    
	    // Create the scroll pane with the fixed size
	    JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(0, 0, 883, 500);
	    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	    contentPane.add(scrollPane);
	    
	    JPanel contentPane_1 = new JPanel();
	    contentPane_1.setPreferredSize(new Dimension(895, 800)); // adjust the height as needed
	    contentPane_1.setLayout(null);
	    contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
	    contentPane_1.setBackground(new Color(250, 250, 250));
	    scrollPane.setViewportView(contentPane_1);
	    
	    JLabel nameLabel = new JLabel("Your residential address in your home country. ");
	    nameLabel.setForeground(new Color(0, 0, 0));
	    nameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    nameLabel.setBounds(75, 100, 300, 39);
	    contentPane_1.add(nameLabel);
	  
	    textField = new JTextField();
	    textField.setBounds(375, 100, 300, 30);
	    contentPane_1.add(textField);
	    
	    JLabel familyNameLabel = new JLabel("Telephone number in your home country. ");
	    familyNameLabel.setForeground(new Color(0, 0, 0));
	    familyNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    familyNameLabel.setBounds(75, 140, 300, 30);
	    contentPane_1.add(familyNameLabel);
	  
	    textField_1 = new JTextField();
	    textField_1.setBounds(375, 140, 300, 30);
	    contentPane_1.add(textField_1);
	    
	    JLabel givenNameLabel = new JLabel("<html>Name and address for communication<br>about this application.</html>");
	    givenNameLabel.setForeground(new Color(0, 0, 0));
	    givenNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    givenNameLabel.setBounds(75, 180, 300, 30);
	    contentPane_1.add(givenNameLabel);
	    
	    textField_2 = new JTextField();
	    textField_2.setBounds(375, 261, 300, 30);
	    contentPane_1.add(textField_2);
	    
	    JLabel birthplaceLabel = new JLabel("Telephone Number");
	    birthplaceLabel.setForeground(new Color(0, 0, 0));
	    birthplaceLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    birthplaceLabel.setBounds(75, 341, 300, 30);
	    contentPane_1.add(birthplaceLabel);
	  
	    textField_3 = new JTextField();
	    textField_3.setBounds(375, 302, 300, 30);
	    contentPane_1.add(textField_3);
	    
	    JLabel expiryDateLabel = new JLabel("Upload I-20");
	    expiryDateLabel.setForeground(new Color(0, 0, 0));
	    expiryDateLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    expiryDateLabel.setBounds(75, 476, 300, 30);
	    contentPane_1.add(expiryDateLabel);
	    
	    JLabel countryLabel = new JLabel("DS-160");
	    countryLabel.setForeground(new Color(0, 0, 0));
	    countryLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    countryLabel.setBounds(75, 517, 300, 30);
	    contentPane_1.add(countryLabel);
	    
	    JLabel citizenshipLabel = new JLabel("<html>Provide the date to which your course fees have been paid. If you have a scholarship, <br>provide the date your scholarship ends<html>");
	    citizenshipLabel.setForeground(new Color(0, 0, 0));
	    citizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    citizenshipLabel.setBounds(75, 558, 300, 71);
	    contentPane_1.add(citizenshipLabel);
	    
	    JLabel otherCitizenshipLabel = new JLabel("Course you have enrolled in");
	    otherCitizenshipLabel.setForeground(new Color(0, 0, 0));
	    otherCitizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    otherCitizenshipLabel.setBounds(75, 640, 246, 30);
	    contentPane_1.add(otherCitizenshipLabel);
	    
	    textField_6 = new JTextField();
	    textField_6.setBounds(375, 580, 300, 30);
	    contentPane_1.add(textField_6);
	    
	    JPanel panel_1 = new JPanel();
	    panel_1.setBackground(new Color(0, 0, 64));
	    panel_1.setLayout(null);
	    panel_1.setBounds(0, 51, 883, 32);
	    contentPane_1.add(panel_1);
	    
	    JLabel lblNewLabel = new JLabel("Section-B");
	    lblNewLabel.setForeground(new Color(255, 255, 255));
	    lblNewLabel.setFont(new Font("Castellar", Font.BOLD, 25));
	    lblNewLabel.setBounds(10, 0, 176, 32);
	    panel_1.add(lblNewLabel);
	    
	    JLabel lblNewLabel_1 = new JLabel("UNITED STATES OF AMERICA");
	    lblNewLabel_1.setForeground(new Color(0, 0, 64));
	    lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 35));
	    lblNewLabel_1.setBounds(0, 0, 649, 54);
	    contentPane_1.add(lblNewLabel_1);
	    
	    JLabel familyNameLabel_1 = new JLabel("Family/last name");
	    familyNameLabel_1.setForeground(new Color(0, 0, 0));
	    familyNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    familyNameLabel_1.setBounds(75, 260, 300, 30);
	    contentPane_1.add(familyNameLabel_1);
	    
	    JLabel givenNameLabel_1 = new JLabel("Given/first name(s)");
	    givenNameLabel_1.setForeground(new Color(0, 0, 0));
	    givenNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    givenNameLabel_1.setBounds(75, 300, 300, 30);
	    contentPane_1.add(givenNameLabel_1);
	    
	    textField_7 = new JTextField();
	    textField_7.setBounds(375, 341, 300, 30);
	    contentPane_1.add(textField_7);
	    
	    textField_8 = new JTextField();
	    textField_8.setBounds(375, 379, 300, 30);
	    contentPane_1.add(textField_8);
	    
	    JLabel lblEmail = new JLabel("Email");
	    lblEmail.setForeground(new Color(0, 0, 0));
	    lblEmail.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
	    lblEmail.setBounds(75, 382, 300, 30);
	    contentPane_1.add(lblEmail);
	    
	    JPanel panel_1_1 = new JPanel();
	    panel_1_1.setBackground(new Color(0, 0, 64));
	    panel_1_1.setLayout(null);
	    panel_1_1.setBounds(0, 427, 883, 32);
	    contentPane_1.add(panel_1_1);
	    
	    JLabel lblSectione = new JLabel("Section-C");
	    lblSectione.setForeground(new Color(255, 255, 255));
	    lblSectione.setFont(new Font("Castellar", Font.BOLD, 25));
	    lblSectione.setBounds(10, 0, 176, 32);
	    panel_1_1.add(lblSectione);
	      
	    JButton btnNewButton = new JButton("Back");
	    btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 12));
	    btnNewButton.setBackground(new Color(192, 192, 192));
	    btnNewButton.setBounds(283, 712, 114, 30);
	    btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				USA usa = new USA();
				usa.setBounds(100, 100, 895, 500);
				dispose();
			}
		});
	    contentPane_1.add(btnNewButton);
	    
	    JButton btnNext = new JButton("Next");
	    btnNext.setForeground(new Color(255, 255, 255));
	    btnNext.setBackground(new Color(0, 0, 64));
	    btnNext.setFont(new Font("SansSerif", Font.BOLD, 12));
	    btnNext.setBounds(438, 712, 114, 30);
	    contentPane_1.add(btnNext);
	    btnNext.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	            if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || 
	            		textField_3.getText().isEmpty() || textField_6.getText().isEmpty() || textField_7.getText().isEmpty() 
	            		||textField_8.getText().isEmpty()) {
	                JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
	            } else {
	            	//
	            	//textField textField_1 textField_2 textField_3 textField_7 textField_8 textField_3
	            	ArrayList<String> tbName = readAndCleanFile("file.txt");
		        	System.out.println(tbName.get(0));
		        	int Id = getLastInsertedID("SecB_"+tbName.get(0)+"_USA") + 1;
		        	
		        	String ResidentialADD =textField.getText();
		        	String Telephone = textField_1.getText();
		        	String lastName = textField_2.getText();
		        	String firstName = textField_3.getText();
		        	String Telephone_NO =textField_7.getText();
		        	String Email = textField_8.getText();
		        	
	            	insertDataB(tbName.get(0), Id, ResidentialADD, Telephone, lastName, firstName, Telephone_NO, Email);
	            	//
	            	USAC usc = new USAC();
					usc.setVisible(true);
					usc.setBounds(100,100,895,500);
					dispose();
	            }
	        }
	    });
	    
	    textField_9 = new JTextField();
	    textField_9.setBounds(375, 203, 300, 47);
	    contentPane_1.add(textField_9);
	    
	    JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Same as address provided ");
	    rdbtnNewRadioButton_1.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNewRadioButton_1.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton_1.setBounds(375, 179, 180, 23);
	    contentPane_1.add(rdbtnNewRadioButton_1);
	    
	    JRadioButton rdbtnNewRadioButton_1_1 = new JRadioButton("As Below");
	    rdbtnNewRadioButton_1_1.setFont(new Font("Dialog", Font.PLAIN, 12));
	    rdbtnNewRadioButton_1_1.setBackground(new Color(250, 250, 250));
	    rdbtnNewRadioButton_1_1.setBounds(557, 179, 109, 23);
	    contentPane_1.add(rdbtnNewRadioButton_1_1);
	    
	    JButton btnNewButton_1 = new JButton("Upload Document");
	    btnNewButton_1.setBackground(new Color(255, 255, 255));
	    btnNewButton_1.addActionListener(new ActionListener() {
	    	 @Override
		        public void actionPerformed(ActionEvent e) {
		            JFileChooser fileChooser = new JFileChooser();
		            int returnValue = fileChooser.showOpenDialog(null);
		            if (returnValue == JFileChooser.APPROVE_OPTION) {
		                File selectedFile = fileChooser.getSelectedFile();
		                try {
		                    // Copy the selected file to the desired location
		                	Files.copy(selectedFile.toPath(), Paths.get("Uploads/" + selectedFile.getName()));

		                    // Show success message
		                    JOptionPane.showMessageDialog(null, "File uploaded successfully.");
		                } catch (IOException ex) {
		                    // Show error message
		                    JOptionPane.showMessageDialog(null, "Error uploading file: " + ex.getMessage());
		                }
		            }
		        }
		    });
	    btnNewButton_1.setBounds(375, 476, 300, 30);
	    contentPane_1.add(btnNewButton_1);
	    
	    JButton btnNewButton_1_1 = new JButton("Upload Document");
	    btnNewButton_1_1.setBackground(new Color(255, 255, 255));
	    btnNewButton_1_1.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            JFileChooser fileChooser = new JFileChooser();
	            int returnValue = fileChooser.showOpenDialog(null);
	            if (returnValue == JFileChooser.APPROVE_OPTION) {
	                File selectedFile = fileChooser.getSelectedFile();
	                try {
	                    // Copy the selected file to the desired location
	                	Files.copy(selectedFile.toPath(), Paths.get("Uploads/" + selectedFile.getName()));

	                    // Show success message
	                    JOptionPane.showMessageDialog(null, "File uploaded successfully.");
	                } catch (IOException ex) {
	                    // Show error message
	                    JOptionPane.showMessageDialog(null, "Error uploading file: " + ex.getMessage());
	                }
	            }
	        }
	    });
	    btnNewButton_1_1.setBounds(375, 522, 300, 30);
	    contentPane_1.add(btnNewButton_1_1);
	    
	    textField_4 = new JTextField();
	    textField_4.setBounds(375, 640, 300, 30);
	    contentPane_1.add(textField_4);

	    
	}
}