package USA;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;

public class USABTour extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					USABTour frame = new USABTour();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public USABTour() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 895, 839);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 64));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(250, 250, 250));
        panel_1.setPreferredSize(new Dimension(883, 750));
        
        JScrollPane contentScrollPane = new JScrollPane(panel_1, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panel_1.setLayout(null);
        
        JLabel nameLabel = new JLabel("Your residential address in your home country. ");
        nameLabel.setForeground(Color.BLACK);
        nameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        nameLabel.setBounds(85, 100, 302, 39);
        panel_1.add(nameLabel);
        
        textField = new JTextField();
        textField.setBounds(385, 100, 300, 30);
        panel_1.add(textField);
        
        JLabel familyNameLabel = new JLabel("Telephone number in your home country. ");
        familyNameLabel.setForeground(Color.BLACK);
        familyNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        familyNameLabel.setBounds(85, 140, 274, 30);
        panel_1.add(familyNameLabel);
        
        textField_1 = new JTextField();
        textField_1.setBounds(385, 148, 300, 30);
        panel_1.add(textField_1);
        
        JLabel givenNameLabel = new JLabel("<html>Name and address for communication<br>about this application.</html>");
        givenNameLabel.setForeground(Color.BLACK);
        givenNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        givenNameLabel.setBounds(85, 180, 261, 30);
        panel_1.add(givenNameLabel);
        
        textField_2 = new JTextField();
        textField_2.setBounds(385, 248, 300, 30);
        panel_1.add(textField_2);
        
        JLabel birthplaceLabel = new JLabel("Telephone Number");
        birthplaceLabel.setForeground(Color.BLACK);
        birthplaceLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        birthplaceLabel.setBounds(85, 329, 170, 30);
        panel_1.add(birthplaceLabel);
        
        textField_3 = new JTextField();
        textField_3.setBounds(385, 290, 300, 30);
        panel_1.add(textField_3);
        
        JLabel expiryDateLabel = new JLabel("Visa that you are applying for");
        expiryDateLabel.setForeground(Color.BLACK);
        expiryDateLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        expiryDateLabel.setBounds(85, 454, 244, 30);
        panel_1.add(expiryDateLabel);
        
        JLabel countryLabel = new JLabel("DS/160");
        countryLabel.setForeground(Color.BLACK);
        countryLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        countryLabel.setBounds(85, 504, 218, 30);
        panel_1.add(countryLabel);
        
        JLabel citizenshipLabel = new JLabel("<html>Proof of the purpose of your stay<html>");
        citizenshipLabel.setForeground(Color.BLACK);
        citizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        citizenshipLabel.setBounds(85, 550, 218, 30);
        panel_1.add(citizenshipLabel);
        
        JLabel otherCitizenshipLabel = new JLabel("Proof of your intent to depart the US");
        otherCitizenshipLabel.setForeground(Color.BLACK);
        otherCitizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        otherCitizenshipLabel.setBounds(85, 600, 251, 30);
        panel_1.add(otherCitizenshipLabel);
        
        textField_5 = new JTextField();
        textField_5.setBounds(385, 550, 300, 30);
        panel_1.add(textField_5);
        
        JLabel lblNewLabel_1 = new JLabel("UNITED STATES OF AMERICA (Tourist Visa)\r\n");
        lblNewLabel_1.setForeground(new Color(0, 0, 64));
        lblNewLabel_1.setFont(new Font("Century", Font.BOLD, 33));
        lblNewLabel_1.setBounds(10, 0, 883, 54);
        panel_1.add(lblNewLabel_1);
        
        JLabel familyNameLabel_1 = new JLabel("Family/last name");
        familyNameLabel_1.setForeground(Color.BLACK);
        familyNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        familyNameLabel_1.setBounds(85, 248, 152, 30);
        panel_1.add(familyNameLabel_1);
        
        JLabel givenNameLabel_1 = new JLabel("Given/first name(s)");
        givenNameLabel_1.setForeground(Color.BLACK);
        givenNameLabel_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        givenNameLabel_1.setBounds(85, 288, 170, 30);
        panel_1.add(givenNameLabel_1);
        
        textField_6 = new JTextField();
        textField_6.setBounds(385, 329, 300, 30);
        panel_1.add(textField_6);
        
        textField_7 = new JTextField();
        textField_7.setBounds(385, 367, 300, 30);
        panel_1.add(textField_7);
        
        JLabel lblEmail = new JLabel("Email");
        lblEmail.setForeground(Color.BLACK);
        lblEmail.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        lblEmail.setBounds(85, 370, 180, 30);
        panel_1.add(lblEmail);
        
        JPanel panel_1_1 = new JPanel();
        panel_1_1.setLayout(null);
        panel_1_1.setForeground(Color.WHITE);
        panel_1_1.setBackground(new Color(0, 0, 64));
        panel_1_1.setBounds(0, 410, 893, 32);
        panel_1.add(panel_1_1);
        
        JLabel lblSectione = new JLabel("Section-C");
        lblSectione.setForeground(Color.WHITE);
        lblSectione.setFont(new Font("Castellar", Font.BOLD, 25));
        lblSectione.setBounds(10, 0, 176, 32);
        panel_1_1.add(lblSectione);
        
        textField_8 = new JTextField();
        textField_8.setColumns(10);
        textField_8.setBounds(385, 599, 300, 30);
        panel_1.add(textField_8);
        
        JLabel lblNewLabel_2 = new JLabel("<html>Proof of your ability to pay all the costs <br>of the trip</html>");
        lblNewLabel_2.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(85, 650, 267, 39);
        panel_1.add(lblNewLabel_2);
        
        textField_9 = new JTextField();
        textField_9.setColumns(10);
        textField_9.setBounds(385, 649, 300, 30);
        panel_1.add(textField_9);
        
        JPanel panel_1_1_1 = new JPanel();
        panel_1_1_1.setLayout(null);
        panel_1_1_1.setForeground(Color.WHITE);
        panel_1_1_1.setBackground(new Color(0, 0, 64));
        panel_1_1_1.setBounds(0, 58, 893, 32);
        panel_1.add(panel_1_1_1);
        
        JLabel lblSectionb = new JLabel("Section-B");
        lblSectionb.setForeground(Color.WHITE);
        lblSectionb.setFont(new Font("Castellar", Font.BOLD, 25));
        lblSectionb.setBounds(10, 0, 176, 32);
        panel_1_1_1.add(lblSectionb);
        
        JButton btnNewButton = new JButton("Back");
        btnNewButton.setBackground(new Color(192, 192, 192));
        btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnNewButton.setBounds(299, 703, 90, 30);
        panel_1.add(btnNewButton);
        
        JButton btnNext = new JButton("Next");
        btnNext.setForeground(new Color(255, 255, 255));
        btnNext.setBackground(new Color(0, 0, 64));
        btnNext.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnNext.setBounds(449, 703, 90, 30);
        panel_1.add(btnNext);
        
        JComboBox<Object> comboBox = new JComboBox<Object>();
        comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Select an Option", "B-1 ", "B-2", "Transit C", "Transit C-1,D"}));
        comboBox.setBounds(385, 459, 300, 30);
        panel_1.add(comboBox);
        
        JButton btnNewButton_1_1 = new JButton("Upload Document");
        btnNewButton_1_1.addActionListener(new ActionListener() {
        	 @Override
 	        public void actionPerformed(ActionEvent e) {
 	            JFileChooser fileChooser = new JFileChooser();
 	            int returnValue = fileChooser.showOpenDialog(null);
 	            if (returnValue == JFileChooser.APPROVE_OPTION) {
 	                File selectedFile = fileChooser.getSelectedFile();
 	                try {
 	                	Files.copy(selectedFile.toPath(), Paths.get("Uploads/" + selectedFile.getName()));
 	                    JOptionPane.showMessageDialog(null, "File uploaded successfully.");
 	                } catch (IOException ex) {
 	                    JOptionPane.showMessageDialog(null, "Error uploading file: " + ex.getMessage());
 	                }
 	            }
 	        }
 	    });
        
        btnNewButton_1_1.setBackground(new Color(255, 255, 255));
        btnNewButton_1_1.setBounds(385, 504, 300, 30);
        panel_1.add(btnNewButton_1_1);
        
        textField_4 = new JTextField();
        textField_4.setBounds(385, 210, 300, 30);
        panel_1.add(textField_4);
        
        JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Same as address provided ");
        rdbtnNewRadioButton_1.setFont(new Font("Dialog", Font.PLAIN, 12));
        rdbtnNewRadioButton_1.setBackground(new Color(250, 250, 250));
        rdbtnNewRadioButton_1.setBounds(386, 185, 180, 23);
        panel_1.add(rdbtnNewRadioButton_1);
        
        JRadioButton rdbtnNewRadioButton_1_1 = new JRadioButton("As Below");
        rdbtnNewRadioButton_1_1.setFont(new Font("Dialog", Font.PLAIN, 12));
        rdbtnNewRadioButton_1_1.setBackground(new Color(250, 250, 250));
        rdbtnNewRadioButton_1_1.setBounds(568, 185, 109, 23);
        panel_1.add(rdbtnNewRadioButton_1_1);
        contentScrollPane.setBackground(new Color(0, 0, 64));
        contentScrollPane.setBounds(0, 0, 883, 500);
        contentPane.add(contentScrollPane);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBackground(new Color(242, 242, 242));
		contentPane_1.setBounds(0, 0, 883, 822);
		contentPane.add(contentPane_1);
		
	}
}