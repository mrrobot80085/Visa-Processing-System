package USA;

import java.awt.EventQueue;
import VisaGUI.HomeLog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DateFormatter;
import javax.swing.text.DefaultFormatterFactory;

import JDBC.CreateDatabase;

import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class USAC extends JFrame {

	private static final long serialVersionUID = 1L;
	protected static final String Dialog = null;
	private JPanel contentPane;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					USAC frame = new USAC();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void insertDataD(String tbName,int id, String Signature, String Date) {
		   String jdbcDriver = "com.mysql.jdbc.Driver";
	       String dbUrl = "jdbc:mysql://localhost/";
	       String dbName = "VisaProcessingSystem";
	       String tb_Name = "VPS_UserData";
	       //System.out.println(passport_Exp);
	       
	       CreateDatabase.main(null);
	       File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
	       ArrayList<String> lines = new ArrayList<>();

	       try {
	           Scanner scanner = new Scanner(file);

	           while (scanner.hasNextLine()) {
	               String line = scanner.nextLine();
	               lines.add(line); // Append line to ArrayList
	           }

	           scanner.close();

	       } catch (FileNotFoundException e) {
	           e.printStackTrace();
	       }
	    // Database credentials
	       String username = lines.get(0);
	       String password = lines.get(1);
	       Connection conn = null;
		
		try {
			System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl+dbName, username, password);
            
			String query = "INSERT INTO secD_" + tbName + "_" + "USA" + " (ID, Signature, Date) " +
			     "VALUES (?, ?, ?)";

			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.setInt(1, id);
			stmt.setString(2, Signature);
			stmt.setString(3, Date);

			stmt.executeUpdate();
			System.out.println("Data inserted successfully!");
			} catch (SQLException ex) {
			System.out.println("Error: " + ex.getMessage());
			}catch (Exception e) {
	            // Handle errors for Class.forName
	            e.printStackTrace();
	        } finally {
	            // Close resources
	            try {
	                if (conn != null)
	                    conn.close();
	            } catch (SQLException se) {
	                se.printStackTrace();
	            }
	        }
	}
	
	public int getLastInsertedID(String tbName) {
    	// JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        //Connection conn = null;
        //Statement stmt = null;
        int id = 0;
        try {
        	Connection conn = DriverManager.getConnection(dbUrl+dbName, username, password);
            String query = "SELECT ID FROM " + tbName + " ORDER BY ID DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                id = rs.getInt("ID");
            }
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return id;
    }
	
	public static ArrayList<String> readAndCleanFile(String filePath) {
        File file = new File(filePath);
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().replaceAll("\\s+", "");
                lines.add(line);
                System.out.println(line);
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return lines;
    }

	/**
	 * Create the frame.
	 */
	public USAC() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 895, 940);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(242, 242, 242));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPanel1 = new JPanel();
		contentPanel1.setBackground(new Color(242, 242, 242));
		contentPanel1.setPreferredSize(new Dimension(873, 833));
		contentPanel1.setLayout(null);

		JScrollPane contentScrollPane = new JScrollPane(contentPanel1, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
		                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contentScrollPane.setBackground(new Color(0, 0, 64));
        
        contentPane.add(contentScrollPane);
        		
        		textField_1 = new JTextField();
        		textField_1.setColumns(10);
        		textField_1.setBounds(219, 707, 170, 30);
        		contentPanel1.add(textField_1);
        		
        		JLabel lblNewLabel_2 = new JLabel("Signature of applicant:");
        		lblNewLabel_2.setForeground(new Color(0, 0, 0));
        		lblNewLabel_2.setFont(new Font("Javanese Text", Font.PLAIN, 18));
        		lblNewLabel_2.setBounds(37, 711, 192, 26);
        		contentPanel1.add(lblNewLabel_2);
        		
        		JLabel lblNewLabel_2_1 = new JLabel("Date:");
        		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
        		lblNewLabel_2_1.setForeground(new Color(0, 0, 0));
        		lblNewLabel_2_1.setFont(new Font("Javanese Text", Font.PLAIN, 18));
        		lblNewLabel_2_1.setBounds(510, 716, 57, 23);
        		contentPanel1.add(lblNewLabel_2_1);
        		
        		JPanel panel = new JPanel();
        		panel.setBackground(new Color(0, 0, 64));
        		panel.setForeground(new Color(0, 0, 0));
        		panel.setLayout(null);
        		panel.setBounds(0, 51, 883, 32);
        		contentPanel1.add(panel);
        		
        		JLabel lblSection = new JLabel("Section-D");
        		lblSection.setForeground(new Color(255, 255, 255));
        		lblSection.setFont(new Font("Castellar", Font.BOLD, 25));
        		lblSection.setBounds(10, 0, 176, 32);
        		panel.add(lblSection);
        		
        		JLabel lblNewLabel = new JLabel("<html>All applicants must complete this section.<br>\r\n<br>I have provided true and correct answers to the questions in this form.\r\n<br>I agree to tell Immigration United States of America about any changes to my circumstances that occur after making this application. <br>\r\n<br>I agree to leave the United States of America before my visa expires. If I remain in the United States of America after my visa has expired, I may be liable for deportation.<br>\r\n<br>I agree that if I am not entitled to free health care in the United States of America, I will pay for any health care or medical assistance I may require in the United States of America.<br>\r\n<br>I understand that if I have received immigration advice from an immigration adviser and if that immigration adviser is not licensed under the Immigration Advisers Licensing Act 2007 when they should be, Immigration United States of America will return my application.<br>\r\n<br>I understand that Immigration United States of America may provide information about my entitlement to work to potential employers via the online VisaView system. VisaView is authorised by legislation.<br>\r\n<br>I authorise Immigration United States of America to provide information about my health and my immigration status to any health service agency. I authorise any health service agency to provide information about my health to Immigration United States of America.<br> \r\n<br>I authorise Immigration United States of America to make any necessary enquiries about information on this form so that they can:<br>\r\n<br>•\tmake a decision on this application<br>\r\n<br>•\tanswer enquiries about my immigration status once my application has been decided.<br>\r\n<br>I authorise any agency that holds information (including personal information) related to those matters to disclose that information to Immigration United States of America.<br>\r\n<br>I authorise Immigration United States of America to provide information about my immigration status to my past, present or future education provider and to the International Education Appeal Authority.<br>\r\n<br>If I am granted a student visa with the condition that I am accompanied by a legal guardian, I agree to live with my legal guardian. I understand that my visa and the visa of my legal guardian may be withdrawn if I do not meet this condition.<br>\r\n<br>If I am granted a limited visa, I agree that I will leave the United States of America on or before the expiry date of that visa. If I do not leave the United States of America, I may be immediately deported from the United States of America without the right of appeal.<html>");
        		lblNewLabel.setForeground(new Color(0, 0, 0));
        		lblNewLabel.setFont(new Font("Leelawadee UI", Font.PLAIN, 12));
        		lblNewLabel.setBounds(10, 78, 849, 622);
        		contentPanel1.add(lblNewLabel);
        		
        		JButton btnNewButton = new JButton("Back");
        		btnNewButton.setForeground(new Color(0, 0, 0));
        		btnNewButton.setBackground(new Color(192, 192, 192));
        		btnNewButton.setFont(new Font("Leelawadee UI", Font.BOLD, 14));
        		btnNewButton.setBounds(300, 764, 89, 23);
        		contentPanel1.add(btnNewButton);
        
        		JLabel lblNewLabel_1 = new JLabel("UNITED STATES OF AMERICA");
        		lblNewLabel_1.setForeground(new Color(0, 0, 64));
        		lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 35));
        		lblNewLabel_1.setBounds(0, 0, 649, 54);
        		contentPanel1.add(lblNewLabel_1);
        		
        		JButton btnNewButton_1 = new JButton("");
        		btnNewButton_1.setBackground(new Color(255, 255, 255));
        		btnNewButton_1.addActionListener(new ActionListener() {
        		    public void actionPerformed(ActionEvent e) {
        		    	// Get the current date
                		Calendar currentDate = Calendar.getInstance();
                		String formattedDate = String.format("%1$tY-%1$tm-%1$td", currentDate.getTime());
                		System.out.println(formattedDate);
                		btnNewButton_1.setText(formattedDate);
        		    }
        		});
        		btnNewButton_1.setBounds(577, 709, 170, 30);
        		contentPanel1.add(btnNewButton_1);
        		
        		JButton btnPay_1 = new JButton("PAY");
        		btnPay_1.addActionListener(new ActionListener() {
        			public void actionPerformed(ActionEvent e) {
        				if (textField_1.getText().isEmpty()) {
        		            JOptionPane.showMessageDialog(null, "Please fill in all the required fields");
        		        } else {
        		        	
        		        	//
        	            	//textField textField_1 textField_2 textField_3 textField_7 textField_8 textField_3
        	            	ArrayList<String> tbName = readAndCleanFile("file.txt");
        		        	System.out.println(tbName.get(0));
        		        	int Id = getLastInsertedID("SecD_"+tbName.get(0)+"_USA") + 1;
        		        	
        		        	String Signature =textField_1.getText();
        		        	String Date = btnNewButton_1.getText();
        		        	
        	            	insertDataD(tbName.get(0), Id, Signature, Date);
        	            	//
        		        	
        		            JDialog dialog = new JDialog();
        		            dialog.setTitle("Payment Information");
        		            dialog.setSize(600, 400);
        		            dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        		            dialog.getContentPane().setLayout(null);
        		            dialog.getContentPane().setBackground(new Color(0, 0, 64));
        		            dialog.setVisible(true);

        		            JLabel lblNewLabel_1 = new JLabel("Payment");
        		            lblNewLabel_1.setForeground(new Color(255,255,255));
        		            lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 20));
        		            lblNewLabel_1.setBounds(219, 11, 124, 36);
        		            dialog.getContentPane().add(lblNewLabel_1);

        		            JLabel amountLabel = new JLabel("Payment Amount: ");
        		            amountLabel.setForeground(new Color(255, 255, 255));
        		            amountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            amountLabel.setBounds(95, 58, 150, 20);
        		            dialog.getContentPane().add(amountLabel);

        		            JLabel currencyLabel = new JLabel("Currency:");
        		            currencyLabel.setForeground(new Color(255, 255, 255));
        		            currencyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            currencyLabel.setBounds(95, 89, 150, 20);
        		            dialog.getContentPane().add(currencyLabel);

        		            JComboBox<String> currency = new JComboBox<String>();
        		            currency.setBounds(255, 89, 200, 20);
        		            dialog.getContentPane().add(currency);
        		            currency.addItem("INR - Indian Rupee");
        		            currency.addItem("USD - US Dollar");

        		            JTextField paymentAmountField = new JTextField();
        		            paymentAmountField.setBounds(255, 58, 200, 20);
        		            paymentAmountField.setText("5000 INR");
        		            dialog.getContentPane().add(paymentAmountField);

        		            currency.addActionListener(new ActionListener() {
        		                public void actionPerformed(ActionEvent e) {
        		                    String selectedCurrency = (String) currency.getSelectedItem();
        		                    if (selectedCurrency.equals("USD - US Dollar")) {
        		                        try {
        		                            String paymentAmountString = paymentAmountField.getText();
        		                            double paymentAmount = Double.parseDouble(paymentAmountString.split(" ")[0]); // Extract the number part of the string
        		                            double convertedAmount = paymentAmount * 0.013; // Conversion rate as of April 2023
        		                            paymentAmountField.setText(String.format("%.2f", convertedAmount) + " USD");
        		                        } catch (NumberFormatException ex) {
        		                            paymentAmountField.setText("Invalid amount entered.");
        		                        }
        		                    } else if (selectedCurrency.equals("INR - Indian Rupee")) {
        		                        paymentAmountField.setText("5000 INR");
        		                    }
        		                }
        		            });

        		            JLabel paymentMethodsLabel = new JLabel("<html>Preferred methods of <br> payment:");
        		            paymentMethodsLabel.setForeground(new Color(255,255,255));
        		            paymentMethodsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        		            paymentMethodsLabel.setBounds(95, 117, 137, 42);
        		            dialog.getContentPane().add(paymentMethodsLabel);

        		            JRadioButton bankChequeButton = new JRadioButton("Mastercard");
        		            bankChequeButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            bankChequeButton.setForeground(new Color(255,255,255));
        		            bankChequeButton.setBackground(new Color(0, 0, 64));
        		            bankChequeButton.setBounds(255, 120, 124, 20);
        		            dialog.getContentPane().add(bankChequeButton);

        		            JRadioButton visaButton = new JRadioButton("Visa");
        		            visaButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            visaButton.setForeground(new Color(255,255,255));
        		            visaButton.setBackground(new Color(0, 0 ,64));
        		            visaButton.setBounds(391, 120, 69, 20);
        		            dialog.getContentPane().add(visaButton);
        		            
        		            ButtonGroup paymentMethodsGroup = new ButtonGroup();
        				    paymentMethodsGroup.add(bankChequeButton);
        		            paymentMethodsGroup.add(visaButton);

        				JLabel cardNumberLabel = new JLabel("Card Number:");
        		        cardNumberLabel.setForeground(new Color(255,255,255));
        		        cardNumberLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        cardNumberLabel.setBounds(95, 173, 150, 20);
        		        dialog.getContentPane().add(cardNumberLabel);

        		        JFormattedTextField amountTextField = new JFormattedTextField();
        		        amountTextField.setBounds(255, 58, 200, 20);
        		        dialog.getContentPane().add(amountTextField);
        		        
        		        JFormattedTextField cardNumberTextField = new JFormattedTextField();
        		        cardNumberTextField.setBounds(255, 173, 200, 20);
        		        dialog.getContentPane().add(cardNumberTextField);

        		        JLabel expiryDateLabel = new JLabel("Expiry Date:");
        		        expiryDateLabel.setForeground(Color.WHITE);
        		        expiryDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        expiryDateLabel.setBounds(95, 204, 150, 20);
        		        dialog.getContentPane().add(expiryDateLabel);

        		        JFormattedTextField expiryDateTextField = new JFormattedTextField();
        		        expiryDateTextField.setBounds(255, 204, 200, 20);
        		        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy");
        		        expiryDateTextField.setFormatterFactory(new DefaultFormatterFactory(new DateFormatter(dateFormat)));
        		        expiryDateTextField.setText("MM/YYYY");
        		        dialog.getContentPane().add(expiryDateTextField);

        		        JLabel cvvLabel = new JLabel("CVV:");
        		        cvvLabel.setForeground(new Color(255,255,255));
        		        cvvLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        cvvLabel.setBounds(95, 235, 150, 20);
        		        dialog.getContentPane().add(cvvLabel);

        		        JPasswordField cvvTextField = new JPasswordField();
        		        cvvTextField.setBounds(255, 235, 200, 20);
        		        dialog.getContentPane().add(cvvTextField);

        		        JButton confirmButton = new JButton("Confirm Payment");
        		        confirmButton.addActionListener(new ActionListener() {
        		            public void actionPerformed(ActionEvent e) {
        		            	String amount = textField_1.getText();
                		        String currencySelection = currency.getSelectedItem().toString();
        		                String paymentMethod = "";
        		                String expiryDate = expiryDateTextField.getText();
        		                if (bankChequeButton.isSelected()) {
        		                    paymentMethod = bankChequeButton.getText();
        		                } else if (visaButton.isSelected()) {
        		                    paymentMethod = visaButton.getText();
        		                }

        		                if (cardNumberTextField.getText().isEmpty()) {
        		                    JOptionPane.showMessageDialog(null, "Payment info not filled. Please fill in all the required fields.");
        		                } else if (!cardNumberTextField.getText().matches("\\d+")) {
        		                    JOptionPane.showMessageDialog(null, "Invalid card number. Only numbers are allowed.");
        		                    return;
        		                } if (!isExpiryDateValid(expiryDate)) {
        		                    JOptionPane.showMessageDialog(dialog, "Invalid expiry date. Please enter a valid expiry date in MM/yyyy format.", "Invalid expiry date", JOptionPane.ERROR_MESSAGE);
        		                    return;
        		                } else if (isExpiryDateLessThan6Months(expiryDate)) {
        		                    JOptionPane.showMessageDialog(dialog, "Expiry date should not be less than 6 months from now.", "Invalid expiry date", JOptionPane.ERROR_MESSAGE);
        		                    return;
        		                } else {
        		                	JOptionPane.showMessageDialog(null, "Payment of " + amount + " " + currencySelection
        	        		                + " using " + paymentMethod + " has been confirmed. You will get all the details mailed to you.");
        		                  }

        		                HomeLog homeFrame = new HomeLog();
        		                homeFrame.setBounds(100, 100, 895, 500);
        		                homeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        		                homeFrame.setVisible(true);
        		                dialog.dispose();
        		            }

        		            private boolean isExpiryDateLessThan6Months(String expiryDate) {
        		                Calendar now = Calendar.getInstance();
        		                Calendar expiry = Calendar.getInstance();
        		                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy");
        		                try {
        		                    Date date = dateFormat.parse(expiryDate);
        		                    expiry.setTime(date);
        		                    expiry.set(Calendar.DAY_OF_MONTH, expiry.getActualMaximum(Calendar.DAY_OF_MONTH));
        		                    expiry.add(Calendar.DAY_OF_MONTH, 1);
        		                } catch (ParseException e) {
        		                    return false;
        		                }
        		                return now.getTimeInMillis() + (6 * 30 * 24 * 60 * 60 * 1000L) > expiry.getTimeInMillis();
        		            }

        		            private boolean isExpiryDateValid(String expiryDate) {
        		                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy");
        		                dateFormat.setLenient(false);
        		                try {
        		                    @SuppressWarnings("unused")
									Date date = dateFormat.parse(expiryDate);
        		                    return true;
        		                } catch (ParseException e) {
        		                    return false;
        		                }
        		            }
        		        
        		        });
        		        confirmButton.setBounds(219, 284, 150, 23);
        		        dialog.getContentPane().add(confirmButton);
        		        dispose();
        		        }
        		      }
        		});
        		btnPay_1.setForeground(new Color(255, 255, 255));
        		btnPay_1.setFont(new Font("Leelawadee UI", Font.BOLD, 14));
        		btnPay_1.setBackground(new Color(0, 0, 64));
        		btnPay_1.setBounds(452, 764, 89, 23);
        		contentPanel1.add(btnPay_1);
        		
		contentScrollPane.setBounds(0, 0, 883, 500);
		contentScrollPane.setBackground(new Color(0, 0, 64));
		contentPane.add(contentScrollPane);
		}
}
