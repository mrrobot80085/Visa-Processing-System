package USA;

import java.awt.EventQueue;
import VisaGUI.HomeLog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DateFormatter;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;

public class USACTour extends JFrame {

	private static final long serialVersionUID = 1L;
	protected static final String Dialog = null;
	private JPanel contentPane;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					USACTour frame = new USACTour();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public USACTour() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 895, 940);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(242, 242, 242));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPanel1 = new JPanel();
		contentPanel1.setBackground(new Color(242, 242, 242));
		contentPanel1.setPreferredSize(new Dimension(873, 813));
		contentPanel1.setLayout(null);

		JScrollPane contentScrollPane = new JScrollPane(contentPanel1, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
		                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contentScrollPane.setBackground(new Color(0, 0, 64));
        
        contentPane.add(contentScrollPane);
        		
        		textField_1 = new JTextField();
        		textField_1.setColumns(10);
        		textField_1.setBounds(219, 707, 170, 30);
        		contentPanel1.add(textField_1);
        		
        		JLabel lblNewLabel_2 = new JLabel("Signature of applicant:");
        		lblNewLabel_2.setForeground(new Color(0, 0, 64));
        		lblNewLabel_2.setFont(new Font("Javanese Text", Font.PLAIN, 18));
        		lblNewLabel_2.setBounds(20, 711, 192, 26);
        		contentPanel1.add(lblNewLabel_2);
        		
        		JButton btnNewButton_1 = new JButton("");
        		btnNewButton_1.setBackground(new Color(255, 255, 255));
        		btnNewButton_1.addActionListener(new ActionListener() {
        		public void actionPerformed(ActionEvent e) {
        		// Get the current date
        		Calendar currentDate = Calendar.getInstance();
        		// Format the date in "dd/MM/yyyy" format
        		String formattedDate = String.format("%1$td/%1$tm/%1$tY", currentDate.getTime());
        		// Change the text of the button to today's date
        		btnNewButton_1.setText(formattedDate);
        		}
        		});
        		btnNewButton_1.setBounds(562, 707, 170, 30);
        		contentPanel1.add(btnNewButton_1);
        		
        		JLabel lblNewLabel_2_1 = new JLabel("Date:");
        		lblNewLabel_2_1.setForeground(new Color(0, 0, 64));
        		lblNewLabel_2_1.setFont(new Font("Javanese Text", Font.PLAIN, 18));
        		lblNewLabel_2_1.setBounds(510, 713, 57, 23);
        		contentPanel1.add(lblNewLabel_2_1);
        		
        		JPanel panel = new JPanel();
        		panel.setBackground(new Color(0, 0, 64));
        		panel.setLayout(null);
        		panel.setBounds(0, 51, 883, 32);
        		contentPanel1.add(panel);
        		
        		JLabel lblSection = new JLabel("Section-D");
        		lblSection.setForeground(new Color(255, 255, 255));
        		lblSection.setFont(new Font("Castellar", Font.BOLD, 25));
        		lblSection.setBounds(10, 0, 176, 32);
        		panel.add(lblSection);
        		
        		JLabel lblNewLabel = new JLabel("<html>All applicants must complete this section.<br>\r\n<br>I have provided true and correct answers to the questions in this form.\r\n<br>I agree to tell Immigration United States of America about any changes to my circumstances that occur after making this application. <br>\r\n<br>I agree to leave the United States of America before my visa expires. If I remain in the United States of America after my visa has expired, I may be liable for deportation.<br>\r\n<br>I agree that if I am not entitled to free health care in the United States of America, I will pay for any health care or medical assistance I may require in the United States of America.<br>\r\n<br>I understand that if I have received immigration advice from an immigration adviser and if that immigration adviser is not licensed under the Immigration Advisers Licensing Act 2007 when they should be, Immigration United States of America will return my application.<br>\r\n<br>I understand that Immigration United States of America may provide information about my entitlement to work to potential employers via the online VisaView system. VisaView is authorised by legislation.<br>\r\n<br>I authorise Immigration United States of America to provide information about my health and my immigration status to any health service agency. I authorise any health service agency to provide information about my health to Immigration United States of America.<br> \r\n<br>I authorise Immigration United States of America to make any necessary enquiries about information on this form so that they can:<br>\r\n<br>•\tmake a decision on this application<br>\r\n<br>•\tanswer enquiries about my immigration status once my application has been decided.<br>\r\n<br>I authorise any agency that holds information (including personal information) related to those matters to disclose that information to Immigration United States of America.<br>\r\n<br>I authorise Immigration United States of America to provide information about my immigration status to my past, present or future education provider and to the International Education Appeal Authority.<br>\r\n<br>If I am granted a student visa with the condition that I am accompanied by a legal guardian, I agree to live with my legal guardian. I understand that my visa and the visa of my legal guardian may be withdrawn if I do not meet this condition.<br>\r\n<br>If I am granted a limited visa, I agree that I will leave the United States of America on or before the expiry date of that visa. If I do not leave the United States of America, I may be immediately deported from the United States of America without the right of appeal.<html>");
        		lblNewLabel.setForeground(new Color(0, 0, 64));
        		lblNewLabel.setFont(new Font("Leelawadee UI", Font.PLAIN, 12));
        		lblNewLabel.setBounds(10, 78, 849, 622);
        		contentPanel1.add(lblNewLabel);
        		
        		JButton btnNewButton = new JButton("Back");
        		btnNewButton.setBackground(new Color(192, 192, 192));
        		btnNewButton.setFont(new Font("Leelawadee UI", Font.BOLD, 14));
        		btnNewButton.setBounds(301, 762, 89, 23);
        		contentPanel1.add(btnNewButton);
        
        		JLabel lblNewLabel_1 = new JLabel("UNITED STATES OF AMERICA");
        		lblNewLabel_1.setForeground(new Color(0, 0, 64));
        		lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 33));
        		lblNewLabel_1.setBounds(0, 0, 649, 54);
        		contentPanel1.add(lblNewLabel_1);
        		
        		JButton btnPay = new JButton("PAY");
        		btnPay.addActionListener(new ActionListener() {
        		    public void actionPerformed(ActionEvent e) {
        		        if (textField_1.getText().isEmpty()) {
        		            JOptionPane.showMessageDialog(null, "Please fill in all the required fields");
        		        } else {
        		        	
        		            JDialog dialog = new JDialog();
        		            dialog.setTitle("Payment Information");
        		            dialog.setSize(600, 400);
        		            dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        		            dialog.getContentPane().setLayout(null);
        		            dialog.getContentPane().setBackground(new Color(0, 0, 64));
        		            dialog.setVisible(true);

        		            JLabel lblNewLabel_1 = new JLabel("Payment");
        		            lblNewLabel_1.setForeground(new Color(255,255,255));
        		            lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 20));
        		            lblNewLabel_1.setBounds(219, 11, 124, 36);
        		            dialog.getContentPane().add(lblNewLabel_1);

        		            JLabel amountLabel = new JLabel("Payment Amount: ");
        		            amountLabel.setForeground(new Color(255, 255, 255));
        		            amountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            amountLabel.setBounds(95, 58, 150, 20);
        		            dialog.getContentPane().add(amountLabel);

        		            JLabel currencyLabel = new JLabel("Currency:");
        		            currencyLabel.setForeground(new Color(255, 255, 255));
        		            currencyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            currencyLabel.setBounds(95, 89, 150, 20);
        		            dialog.getContentPane().add(currencyLabel);

        		            JComboBox<String> currency = new JComboBox<String>();
        		            currency.setBounds(255, 89, 200, 20);
        		            dialog.getContentPane().add(currency);
        		            currency.addItem("INR - Indian Rupee");
        		            currency.addItem("USD - US Dollar");

        		            JTextField paymentAmountField = new JTextField();
        		            paymentAmountField.setBounds(255, 58, 200, 20);
        		            paymentAmountField.setText("5000 INR");
        		            dialog.getContentPane().add(paymentAmountField);

        		            currency.addActionListener(new ActionListener() {
        		                public void actionPerformed(ActionEvent e) {
        		                    String selectedCurrency = (String) currency.getSelectedItem();
        		                    if (selectedCurrency.equals("USD - US Dollar")) {
        		                        try {
        		                            String paymentAmountString = paymentAmountField.getText();
        		                            double paymentAmount = Double.parseDouble(paymentAmountString.split(" ")[0]); // Extract the number part of the string
        		                            double convertedAmount = paymentAmount * 0.013; // Conversion rate as of April 2023
        		                            paymentAmountField.setText(String.format("%.2f", convertedAmount) + " USD");
        		                        } catch (NumberFormatException ex) {
        		                            paymentAmountField.setText("Invalid amount entered.");
        		                        }
        		                    } else if (selectedCurrency.equals("INR - Indian Rupee")) {
        		                        paymentAmountField.setText("5000 INR");
        		                    }
        		                }
        		            });


        		            JLabel paymentMethodsLabel = new JLabel("<html>Preferred methods of <br> payment:");
        		            paymentMethodsLabel.setForeground(new Color(255,255,255));
        		            paymentMethodsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        		            paymentMethodsLabel.setBounds(95, 117, 137, 42);
        		            dialog.getContentPane().add(paymentMethodsLabel);

        		            JRadioButton bankChequeButton = new JRadioButton("Bank Cheque");
        		            bankChequeButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            bankChequeButton.setForeground(new Color(255,255,255));
        		            bankChequeButton.setBackground(new Color(0, 0, 64));
        		            bankChequeButton.setBounds(255, 120, 124, 20);
        		            dialog.getContentPane().add(bankChequeButton);

        		            JRadioButton visaButton = new JRadioButton("Visa");
        		            visaButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		            visaButton.setForeground(new Color(255,255,255));
        		            visaButton.setBackground(new Color(0, 0 ,64));
        		            visaButton.setBounds(391, 120, 69, 20);
        		            dialog.getContentPane().add(visaButton);

        		            // Add radio buttons to a ButtonGroup
        		            ButtonGroup paymentMethodsGroup = new ButtonGroup();
        				    paymentMethodsGroup.add(bankChequeButton);
        		            paymentMethodsGroup.add(visaButton);

        				JLabel cardNumberLabel = new JLabel("Card Number:");
        		        cardNumberLabel.setForeground(new Color(255,255,255));
        		        cardNumberLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        cardNumberLabel.setBounds(95, 173, 150, 20);
        		        dialog.getContentPane().add(cardNumberLabel);

        		        JFormattedTextField amountTextField = new JFormattedTextField();
        		        amountTextField.setBounds(255, 58, 200, 20);
        		        dialog.getContentPane().add(amountTextField);
        		        
        		        JFormattedTextField cardNumberTextField = new JFormattedTextField();
        		        cardNumberTextField.setBounds(255, 173, 200, 20);
        		        dialog.getContentPane().add(cardNumberTextField);

        		        JLabel expiryDateLabel = new JLabel("Expiry Date:");
        		        expiryDateLabel.setForeground(new Color(255,255,255));
        		        expiryDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        expiryDateLabel.setBounds(95, 204, 150, 20);
        		        dialog.getContentPane().add(expiryDateLabel);

        		        JFormattedTextField expiryDateTextField = new JFormattedTextField();
        		        expiryDateTextField.setBounds(255, 204, 200, 20);

        		        // Create a SimpleDateFormat object with the desired format
        		        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yyyy");

        		        // Set the format for the JFormattedTextField
        		        expiryDateTextField.setFormatterFactory(new DefaultFormatterFactory(new DateFormatter(dateFormat)));

        		        // Set the initial text to the desired format
        		        expiryDateTextField.setText("MM/YYYY");

        		        // Add a FocusListener to remove the placeholder text when the user clicks on the field
        		        expiryDateTextField.addFocusListener(new FocusListener() {
        		            @Override
        		            public void focusGained(FocusEvent e) {
        		                // Remove the placeholder text when the user clicks on the field
        		                if (expiryDateTextField.getText().equals("MM/YYYY")) {
        		                    expiryDateTextField.setText("");
        		                }
        		            }

        		            @Override
        		            public void focusLost(FocusEvent e) {
        		                // If the field is empty when the user leaves it, reset the placeholder text
        		                if (expiryDateTextField.getText().isEmpty()) {
        		                    expiryDateTextField.setText("MM/YYYY");
        		                }
        		            }
        		        });

        		        dialog.getContentPane().add(expiryDateTextField);
        		        
        		        JLabel cvvLabel = new JLabel("CVV:");
        		        cvvLabel.setForeground(new Color(255,255,255));
        		        cvvLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        		        cvvLabel.setBounds(95, 235, 150, 20);
        		        dialog.getContentPane().add(cvvLabel);

        		        JPasswordField cvvTextField = new JPasswordField();
        		        cvvTextField.setBounds(255, 235, 200, 20);
        		        dialog.getContentPane().add(cvvTextField);

        		        JButton confirmButton = new JButton("Confirm Payment");
        		        confirmButton.addActionListener(new ActionListener() {
        		            public void actionPerformed(ActionEvent e) {
        		                String paymentAmountField = currency.getSelectedItem().toString();
        		                String paymentMethod = "";
        		                if (bankChequeButton.isSelected()) {
        		                    paymentMethod = bankChequeButton.getText();
        		                } else if (visaButton.isSelected()) {
        		                    paymentMethod = visaButton.getText();
        		                   
        		                }

        		                if (cardNumberTextField.getText().isEmpty()) {
        		                    JOptionPane.showMessageDialog(null, "Payment info not filled. Please fill in all the required fields.");
        		                } else if (!cardNumberTextField.getText().matches("\\d+")) {
        		                    JOptionPane.showMessageDialog(null, "Invalid card number. Only numbers are allowed.");
        		                    return;
        		                } else {
        		                    JOptionPane.showMessageDialog(null, "Payment of " + " " + paymentAmountField
                                            + " using " + paymentMethod + " has been confirmed. You will get all the details mailed to you.");
        		                    }

        		                    HomeLog homeFrame = new HomeLog();
        		                    homeFrame.setBounds(100, 100, 895, 500);
        		                    homeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        		                    homeFrame.setVisible(true);
        		                    dialog.dispose();
        		                }
        		        });
        		        confirmButton.setBounds(219, 284, 150, 23);
        		        dialog.getContentPane().add(confirmButton); 
        		        dispose();
        		        }
        		      }
    		       });
        btnPay.setFont(new Font("Leelawadee UI", Font.BOLD, 14));
        btnPay.setBackground(new Color(0, 128, 255));
        btnPay.setBounds(457, 764, 89, 23);
        
        contentPanel1.add(btnPay);
		contentScrollPane.setBounds(0, 0, 883, 500);
		contentScrollPane.setBackground(new Color(0, 0, 64));
		contentPane.add(contentScrollPane);
		}
}
