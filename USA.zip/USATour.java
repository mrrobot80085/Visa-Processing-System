package USA;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JCalendar;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JDialog;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import javax.swing.JRadioButton;
import VisaGUI.Student;

public class USATour extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    USATour frame = new USATour();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public USATour() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 895, 900);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(242, 242, 242));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        // Set the content pane
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(250, 250, 250));
        panel_1.setLayout(null);
        panel_1.setPreferredSize(new Dimension(883, 700));
        
        JScrollPane contentScrollPane = new JScrollPane(panel_1, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contentScrollPane.setBackground(new Color(0, 0, 64));
        contentScrollPane.setBounds(0, 0, 883, 500);
        contentPane.add(contentScrollPane);
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(0, 0, 64));
        panel.setBounds(0, 56, 878, 32);
        panel_1.add(panel);
        
        JLabel lblNewLabel = new JLabel("Section-A");
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setFont(new Font("Castellar", Font.BOLD, 25));
        lblNewLabel.setBounds(10, 0, 176, 32);
        panel.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel(" UNITED STATES OF AMERICA ");
        lblNewLabel_1.setForeground(new Color(0, 0, 64));
        lblNewLabel_1.setFont(new Font("Castellar", Font.BOLD, 35));
        lblNewLabel_1.setBounds(0, 0, 680, 59);
        panel_1.add(lblNewLabel_1);
        
        JLabel nameLabel = new JLabel("Name as shown in passport");
        nameLabel.setForeground(Color.BLACK);
        nameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        nameLabel.setBounds(80, 105, 300, 30);
        panel_1.add(nameLabel);
        
        textField = new JTextField();
        textField.setBounds(380, 105, 300, 30);
        panel_1.add(textField);
        
        JLabel familyNameLabel = new JLabel("Family/last name");
        familyNameLabel.setForeground(Color.BLACK);
        familyNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        familyNameLabel.setBounds(80, 145, 300, 30);
        panel_1.add(familyNameLabel);
        
        textField_1 = new JTextField();
        textField_1.setBounds(380, 145, 300, 30);
        panel_1.add(textField_1);
        
        JLabel givenNameLabel = new JLabel("Given/first name(s)");
        givenNameLabel.setForeground(Color.BLACK);
        givenNameLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        givenNameLabel.setBounds(80, 185, 300, 30);
        panel_1.add(givenNameLabel);
        
        textField_2 = new JTextField();
        textField_2.setBounds(380, 185, 300, 30);
        panel_1.add(textField_2);
        
        JLabel titleLabel = new JLabel("Preferred title");
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        titleLabel.setBounds(80, 225, 300, 30);
        panel_1.add(titleLabel);
        
        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setForeground(Color.BLACK);
        genderLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        genderLabel.setBounds(80, 265, 300, 30);
        panel_1.add(genderLabel);
        
        JLabel dobLabel = new JLabel("Date of birth");
        dobLabel.setForeground(Color.BLACK);
        dobLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        dobLabel.setBounds(80, 305, 300, 30);
        panel_1.add(dobLabel);
        
        JLabel birthplaceLabel = new JLabel("Town/city of birth");
        birthplaceLabel.setForeground(Color.BLACK);
        birthplaceLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        birthplaceLabel.setBounds(80, 345, 300, 30);
        panel_1.add(birthplaceLabel);
        
        textField_4 = new JTextField();
        textField_4.setBounds(380, 345, 300, 30);
        panel_1.add(textField_4);
        
        JLabel birthCountryLabel = new JLabel("Country/region of birth");
        birthCountryLabel.setForeground(Color.BLACK);
        birthCountryLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        birthCountryLabel.setBounds(80, 385, 300, 30);
        panel_1.add(birthCountryLabel);
        
        textField_5 = new JTextField();
        textField_5.setBounds(380, 385, 300, 30);
        panel_1.add(textField_5);
        
        JLabel passportNumLabel = new JLabel("Passport number");
        passportNumLabel.setForeground(Color.BLACK);
        passportNumLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        passportNumLabel.setBounds(80, 425, 300, 30);
        panel_1.add(passportNumLabel);
        
        textField_6 = new JTextField();
        textField_6.setBounds(380, 425, 300, 30);
        panel_1.add(textField_6);
        
        JLabel expiryDateLabel = new JLabel("Passport expiration date");
        expiryDateLabel.setForeground(Color.BLACK);
        expiryDateLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        expiryDateLabel.setBounds(80, 465, 300, 30);
        panel_1.add(expiryDateLabel);
        
        textField_7 = new JTextField();
        textField_7.setBounds(380, 465, 300, 30);
        panel_1.add(textField_7);
        
        JLabel countryLabel = new JLabel("Country/region where you live");
        countryLabel.setForeground(Color.BLACK);
        countryLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        countryLabel.setBounds(80, 505, 300, 30);
        panel_1.add(countryLabel);
        
        textField_8 = new JTextField();
        textField_8.setBounds(380, 505, 300, 30);
        panel_1.add(textField_8);
        
        JLabel citizenshipLabel = new JLabel("Citizenship");
        citizenshipLabel.setForeground(Color.BLACK);
        citizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        citizenshipLabel.setBounds(80, 545, 300, 30);
        panel_1.add(citizenshipLabel);
        
        textField_9 = new JTextField();
        textField_9.setBounds(380, 545, 300, 30);
        panel_1.add(textField_9);
        
        JLabel otherCitizenshipLabel = new JLabel("Other citizenship/nationality");
        otherCitizenshipLabel.setForeground(Color.BLACK);
        otherCitizenshipLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
        otherCitizenshipLabel.setBounds(80, 585, 300, 30);
        panel_1.add(otherCitizenshipLabel);
        
        textField_10 = new JTextField();
        textField_10.setBounds(380, 585, 300, 30);
        panel_1.add(textField_10);
        
        JButton btnNewButton = new JButton("Back");
        btnNewButton.setBackground(new Color(192, 192, 192));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Student stud = new Student();
        		stud.setVisible(true);
        		dispose();
        	}
        });
        btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnNewButton.setBounds(255, 639, 89, 23);
        panel_1.add(btnNewButton);
        
        JButton btnNext = new JButton("Next");
        btnNext.setForeground(new Color(255, 255, 255));
        btnNext.setBackground(new Color(0, 0, 64));
        btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || 
						textField_4.getText().isEmpty() || textField_5.getText().isEmpty() || 
						textField_6.getText().isEmpty() || textField_7.getText().isEmpty() || textField_8.getText().isEmpty() || 
						textField_9.getText().isEmpty() || textField_10.getText().isEmpty()) {
		            JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
		        } else {
		        	USABTour usb = new USABTour();
		        	usb.setVisible(true);
					usb.setBounds(100, 100, 895, 500);
					usb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		        }
			}
		});
        btnNext.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnNext.setBounds(405, 639, 89, 23);
        panel_1.add(btnNext);
        
        JButton btnNewButton_1 = new JButton("");
        btnNewButton_1.setFont(new Font("SansSerif", Font.PLAIN, 11));
        btnNewButton_1.setForeground(new Color(0, 0, 0));
        btnNewButton_1.addActionListener(new ActionListener() {
            	public void actionPerformed(ActionEvent e) {
            	    JDialog dialog = new JDialog(USATour.this, "Select Date", true);
            	    JPanel panel = new JPanel();
            	    JCalendar calendar = new JCalendar();
            	    calendar.setTodayButtonVisible(true);
            	    calendar.setNullDateButtonVisible(true); // allow selection of today's date
            	    panel.add(calendar);
            	    JButton okButton = new JButton("OK");
            	    okButton.addActionListener(new ActionListener() {
            	        public void actionPerformed(ActionEvent e) {
            	            // Get the selected date from the calendar
            	            Calendar selectedDate = calendar.getCalendar();
            	            if (selectedDate != null) {
            	                // Format the date in "MM/dd/yyyy" format
            	                String formattedDate = String.format("%1$tm/%1$td/%1$tY", selectedDate.getTime());
            	                // Change the text of the button to the selected date
            	                btnNewButton_1.setText(formattedDate);
            	            }
            	            dialog.dispose();
            	        }
            	    });
            	    panel.add(okButton);
            	    dialog.getContentPane().add(panel);
            	    dialog.pack();
            	    dialog.setLocationRelativeTo(USATour.this);
            	    dialog.setVisible(true);
            	}
            }); 
        btnNewButton_1.setBackground(Color.WHITE);
        btnNewButton_1.setBounds(380, 305, 300, 30);
        panel_1.add(btnNewButton_1);
        
        JRadioButton rdbtnMale = new JRadioButton("Male");
        buttonGroup_1.add(rdbtnMale);
        rdbtnMale.setForeground(Color.BLACK);
        rdbtnMale.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnMale.setBackground(new Color(250, 250, 250));
        rdbtnMale.setBounds(380, 268, 56, 23);
        panel_1.add(rdbtnMale);
        
        JRadioButton rdbtnFemale = new JRadioButton("Female");
        buttonGroup_1.add(rdbtnFemale);
        rdbtnFemale.setForeground(Color.BLACK);
        rdbtnFemale.setFont(new Font("Dialog", Font.PLAIN, 11));
        rdbtnFemale.setBackground(new Color(250, 250, 250));
        rdbtnFemale.setBounds(447, 269, 69, 23);
        panel_1.add(rdbtnFemale);
        
        JRadioButton rdbtnMrs = new JRadioButton("Mrs.");
        buttonGroup.add(rdbtnMrs);
        rdbtnMrs.setForeground(Color.BLACK);
        rdbtnMrs.setFont(new Font("Dialog", Font.PLAIN, 12));
        rdbtnMrs.setBackground(new Color(250, 250, 250));
        rdbtnMrs.setBounds(431, 229, 56, 23);
        panel_1.add(rdbtnMrs);
        
        JRadioButton rdbtnMr = new JRadioButton("Mr.");
        buttonGroup.add(rdbtnMr);
        rdbtnMr.setForeground(Color.BLACK);
        rdbtnMr.setFont(new Font("Dialog", Font.PLAIN, 12));
        rdbtnMr.setBackground(new Color(250, 250, 250));
        rdbtnMr.setBounds(380, 229, 56, 23);
        panel_1.add(rdbtnMr);
        
        JRadioButton rdbtnMs = new JRadioButton("Ms.");
        buttonGroup.add(rdbtnMs);
        rdbtnMs.setForeground(Color.BLACK);
        rdbtnMs.setFont(new Font("Dialog", Font.PLAIN, 12));
        rdbtnMs.setBackground(new Color(250, 250, 250));
        rdbtnMs.setBounds(499, 229, 49, 23);
        panel_1.add(rdbtnMs);
        
        JRadioButton rdbtnMiss = new JRadioButton("Miss");
        buttonGroup.add(rdbtnMiss);
        rdbtnMiss.setForeground(Color.BLACK);
        rdbtnMiss.setFont(new Font("Dialog", Font.PLAIN, 12));
        rdbtnMiss.setBackground(new Color(250, 250, 250));
        rdbtnMiss.setBounds(558, 229, 56, 23);
        panel_1.add(rdbtnMiss);
        
        // Set window properties
        setTitle("USA Visa Application Form");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(895, 715);
        setVisible(true);
    }
}

