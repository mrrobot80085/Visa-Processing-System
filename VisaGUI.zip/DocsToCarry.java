package VisaGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DocsToCarry extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

    public DocsToCarry() {
    	setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 895, 500);
        setTitle("Visa Interview Day Documents Checklist");

        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 64));
        contentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 882, 467);
        panel.setBackground(new Color(0, 0, 64));
        contentPane.add(panel);
        panel.setLayout(null);
        
        JCheckBox visaBox_1 = new JCheckBox("Hotel Reservation");
        visaBox_1.setForeground(Color.WHITE);
        visaBox_1.setFont(new Font("Serif", Font.PLAIN, 20));
        visaBox_1.setBackground(new Color(0, 0, 64));
        visaBox_1.setBounds(280, 171, 234, 23);
        panel.add(visaBox_1);
        
        JCheckBox visaBox_1_1 = new JCheckBox("Flight Reservation");
        visaBox_1_1.setForeground(Color.WHITE);
        visaBox_1_1.setFont(new Font("Serif", Font.PLAIN, 20));
        visaBox_1_1.setBackground(new Color(0, 0, 64));
        visaBox_1_1.setBounds(280, 197, 261, 23);
        panel.add(visaBox_1_1);

        JCheckBox passportBox = new JCheckBox("Passport");
        passportBox.setFont(new Font("Serif", Font.PLAIN, 20));
        passportBox.setBounds(40, 145, 234, 23);
        passportBox.setBackground(new Color(0, 0, 64));
        passportBox.setForeground(new Color(255, 255, 255));
        panel.add(passportBox);

        JCheckBox visaBox = new JCheckBox("Visa");
        visaBox.setFont(new Font("Serif", Font.PLAIN, 20));
        visaBox.setBounds(40, 171, 150, 23);
        visaBox.setBackground(new Color(0, 0, 64));
        visaBox.setForeground(new Color(255, 255, 255));
        panel.add(visaBox);

        JCheckBox applicationBox = new JCheckBox("Visa Application Form");
        applicationBox.setFont(new Font("Serif", Font.PLAIN, 20));
        applicationBox.setBounds(40, 197, 316, 23);
        applicationBox.setBackground(new Color(0, 0, 64));
        applicationBox.setForeground(new Color(255, 255, 255));
        panel.add(applicationBox);

        JCheckBox photoBox = new JCheckBox("Photo");
        photoBox.setFont(new Font("Serif", Font.PLAIN, 20));
        photoBox.setBounds(40, 223, 226, 23);
        photoBox.setBackground(new Color(0, 0, 64));
        photoBox.setForeground(new Color(255, 255, 255));
        panel.add(photoBox);

        JCheckBox feeBox = new JCheckBox("Visa Fee");
        feeBox.setFont(new Font("Serif", Font.PLAIN, 20));
        feeBox.setBounds(40, 249, 250, 23);
        feeBox.setBackground(new Color(0, 0, 64));
        feeBox.setForeground(new Color(255, 255, 255));
        panel.add(feeBox);

        JCheckBox itineraryBox = new JCheckBox("Travel Itinerary");
        itineraryBox.setFont(new Font("Serif", Font.PLAIN, 20));
        itineraryBox.setBounds(40, 275, 261, 23);
        itineraryBox.setBackground(new Color(0, 0, 64));
        itineraryBox.setForeground(new Color(255, 255, 255));
        panel.add(itineraryBox);

        JCheckBox insuranceBox = new JCheckBox("Travel Insurance");
        insuranceBox.setFont(new Font("Serif", Font.PLAIN, 20));
        insuranceBox.setBounds(40, 301, 261, 23);
        insuranceBox.setBackground(new Color(0, 0, 64));
        insuranceBox.setForeground(new Color(255, 255, 255));
        panel.add(insuranceBox);

        JCheckBox employmentBox = new JCheckBox("Employment Letter");
        employmentBox.setFont(new Font("Serif", Font.PLAIN, 20));
        employmentBox.setBounds(40, 327, 250, 23);
        employmentBox.setBackground(new Color(0, 0, 64));
        employmentBox.setForeground(new Color(255, 255, 255));
        panel.add(employmentBox);

        JCheckBox bankBox = new JCheckBox("Bank Statements");
        bankBox.setFont(new Font("Serif", Font.PLAIN, 20));
        bankBox.setBounds(40, 353, 316, 23);
        bankBox.setBackground(new Color(0, 0, 64));
        bankBox.setForeground(new Color(255, 255, 255));
        panel.add(bankBox);
        
        JCheckBox visaBox_1_1_1 = new JCheckBox("Passport Copy");
        visaBox_1_1_1.setForeground(Color.WHITE);
        visaBox_1_1_1.setFont(new Font("Serif", Font.PLAIN, 20));
        visaBox_1_1_1.setBackground(new Color(0, 0, 64));
        visaBox_1_1_1.setBounds(280, 223, 150, 23);
        panel.add(visaBox_1_1_1);
        
        JLabel titleLabel = new JLabel("<html>Visa Interview Day Documents Checklist");
        titleLabel.setVerticalAlignment(SwingConstants.BOTTOM);
        titleLabel.setBounds(5, 0, 836, 47);
        titleLabel.setForeground(new Color(255, 255, 255));
        titleLabel.setFont(new Font("Castellar", Font.BOLD, 30));
        panel.add(titleLabel);
        
        JLabel infoLabel = new JLabel("<html>Please make sure you have the following documents with you on the day of your visa interview:");
        infoLabel.setFont(new Font("Rockwell", Font.PLAIN, 20));
        infoLabel.setBounds(35, 88, 806, 52);
        panel.add(infoLabel);
        infoLabel.setForeground(new Color(255, 255, 255));
        
                JLabel noteLabel = new JLabel("Note: The above list is not exhaustive and may vary depending on your specific case.");
                noteLabel.setBounds(28, 368, 844, 53);
                panel.add(noteLabel);
                noteLabel.setForeground(new Color(255, 255, 255));
                noteLabel.setFont(new Font("Rockwell", Font.ITALIC, 22));
                
                JLabel lblNewLabel = new JLabel("OPTIONAL DOCUMENTS TO CARRY");
                lblNewLabel.setFont(new Font("Serif", Font.BOLD, 20));
                lblNewLabel.setForeground(new Color(255, 255, 255));
                lblNewLabel.setBounds(275, 137, 423, 31);
                panel.add(lblNewLabel);
                
                JButton btnNewButton = new JButton("Home");
                btnNewButton.addActionListener(new ActionListener() {
                	public void actionPerformed(ActionEvent e) {
                		HomeLog Hm = new HomeLog();
                		Hm.setVisible(true);
                		dispose();
                	}
                });
                btnNewButton.setBackground(new Color(0, 128, 255));
                btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 20));
                btnNewButton.setBounds(334, 420, 168, 36);
                panel.add(btnNewButton);
                
                JPanel panel_1 = new JPanel();
                panel_1.setLayout(null);
                panel_1.setBackground(Color.WHITE);
                panel_1.setBounds(0, 49, 883, 30);
                panel.add(panel_1);
                
                JButton btnNewButton_3 = new JButton("HOME");
                btnNewButton_3.setVerticalAlignment(SwingConstants.BOTTOM);
                btnNewButton_3.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
                btnNewButton_3.setBorderPainted(false);
                btnNewButton_3.setBackground(Color.WHITE);
                btnNewButton_3.setBounds(179, 1, 155, 30);
                panel_1.add(btnNewButton_3);
                
                JButton btnNewButton_3_1 = new JButton("ABOUT US");
                btnNewButton_3_1.setVerticalAlignment(SwingConstants.BOTTOM);
                btnNewButton_3_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
                btnNewButton_3_1.setBorderPainted(false);
                btnNewButton_3_1.setBackground(Color.WHITE);
                btnNewButton_3_1.setBounds(332, 1, 155, 30);
                panel_1.add(btnNewButton_3_1);
                
                JButton btnNewButton_3_1_1 = new JButton("CONTACT US\r\n");
                btnNewButton_3_1_1.setVerticalAlignment(SwingConstants.BOTTOM);
                btnNewButton_3_1_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
                btnNewButton_3_1_1.setBorderPainted(false);
                btnNewButton_3_1_1.setBackground(Color.WHITE);
                btnNewButton_3_1_1.setBounds(485, 1, 155, 30);
                panel_1.add(btnNewButton_3_1_1);

        setContentPane(contentPane);
        setVisible(true);
    }

    public static void main(String[] args) {
        new DocsToCarry();
    }
}
