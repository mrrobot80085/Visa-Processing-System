package VisaGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.ImageIcon;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.EventObject;

public class Home extends JFrame {

	private static final long serialVersionUID = 1L;
	JFrame frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(0, 0, 0));
		frame.setBounds(100, 100, 895, 500);
		frame.getContentPane().setLayout(null);
		
		JPanel sidebarPanel = new JPanel();
		sidebarPanel.setLayout(null);
		sidebarPanel.setBackground(Color.BLACK);
		sidebarPanel.setBounds(710, 51, 150, 164);
		frame.getContentPane().add(sidebarPanel);
		
		JButton btnNewButton_1 = new JButton("Student ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                Login frame = new Login("Student");
                frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1.setBackground(Color.BLACK);
		btnNewButton_1.setBounds(0, 0, 160, 43);
		sidebarPanel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Tourist");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login("Tourist");
				frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1_1.setBackground(Color.BLACK);
		btnNewButton_1_1.setBounds(0, 39, 150, 43);
		sidebarPanel.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("Docs To Carry");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login("DocsToCarry");
            	frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_1_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1_1_1.setBackground(Color.BLACK);
		btnNewButton_1_1_1.setBounds(-1, 81, 150, 43);
		sidebarPanel.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_2 = new JButton("LogIn/ SignUp");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login("HomeLog");
				frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_1_1_2.setForeground(Color.WHITE);
		btnNewButton_1_1_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1_1_2.setBackground(Color.BLACK);
		btnNewButton_1_1_2.setBounds(-2, 121, 150, 43);
		sidebarPanel.add(btnNewButton_1_1_2);
		
		sidebarPanel.setLayout(null);
		sidebarPanel.add(btnNewButton_1);
		sidebarPanel.add(btnNewButton_1_1);
		sidebarPanel.add(btnNewButton_1_1_1);
		sidebarPanel.add(btnNewButton_1_1_2);
		
		JLabel lblNewLabel = new JLabel("Visa");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Castellar", Font.BOLD, 38));
		lblNewLabel.setBackground(new Color(5, 5, 5));
		lblNewLabel.setBounds(46, 0, 120, 51);
		frame.getContentPane().add(lblNewLabel);
		
		JButton instagram = new JButton("");
		instagram.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\3.png"));
		instagram.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		openWebsite("https://www.instagram.com");
	        	}
	        });
		instagram.setBounds(675, 10, 30, 30);
		frame.getContentPane().add(instagram);
		
		JButton facebook = new JButton("");
		facebook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openWebsite("https://www.facebook.com");
			}
		});
		facebook.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\2.png"));
		facebook.setBounds(724, 10, 30, 30);
		frame.getContentPane().add(facebook);
		
		JButton twitter = new JButton("");
		twitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openWebsite("https://www.twitter.com");
			}
		});
		twitter.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\1.png"));
		twitter.setBounds(774, 10, 30, 30);
		frame.getContentPane().add(twitter);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 50, 883, 30);
		frame.getContentPane().add(panel);
		
		JButton btnNewButton_3 = new JButton("HOME");
		btnNewButton_3.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_3.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(236, 1, 89, 30);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("ABOUT US");
		btnNewButton_3_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3_1.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_3_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3_1.setBorderPainted(false);
		btnNewButton_3_1.setBackground(Color.WHITE);
		btnNewButton_3_1.setBounds(324, 1, 128, 30);
		panel.add(btnNewButton_3_1);
		
		JButton btnNewButton_3_1_1 = new JButton("CONTACT US\r\n");
		btnNewButton_3_1_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3_1_1.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_3_1_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3_1_1.setBorderPainted(false);
		btnNewButton_3_1_1.setBackground(Color.WHITE);
		btnNewButton_3_1_1.setBounds(452, 1, 151, 30);
		panel.add(btnNewButton_3_1_1);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Blank diagram - Page 3 (5) (1).png"));
		btnNewButton.setOpaque(false);
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sidebarPanel.setVisible(!sidebarPanel.isVisible());
            }
        });
		btnNewButton.setBounds(843, 11, 30, 30);
		frame.getContentPane().add(btnNewButton);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(null);
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBounds(16, 91, 851, 340);
		frame.getContentPane().add(mainPanel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\travel the world hassle free.png"));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setBounds(0, 0, 851, 302);
		mainPanel.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Apply for student visa");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login("DocsToCarry");
            	frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2.setBackground(Color.BLACK);
		btnNewButton_2.setBounds(0, 301, 213, 40);
		mainPanel.add(btnNewButton_2);
		
		JButton btnNewButton_2_2 = new JButton("Apply for Tourist Visa");
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login("Tourist");
            	frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_2_2.setForeground(Color.WHITE);
		btnNewButton_2_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2_2.setBackground(Color.BLACK);
		btnNewButton_2_2.setBounds(212, 301, 213, 40);
		mainPanel.add(btnNewButton_2_2);
		
		JButton btnNewButton_2_3 = new JButton("Important Documents");
		btnNewButton_2_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login frame = new Login("DocsToCarry");
            	frame.setVisible(true);
				Home.this.frame.dispose();
			}
		});
		btnNewButton_2_3.setForeground(Color.WHITE);
		btnNewButton_2_3.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2_3.setBackground(Color.BLACK);
		btnNewButton_2_3.setBounds(424, 301, 213, 40);
		mainPanel.add(btnNewButton_2_3);
		
		JButton btnNewButton_2_3_1 = new JButton("About Us");
		btnNewButton_2_3_1.setForeground(Color.WHITE);
		btnNewButton_2_3_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2_3_1.setBackground(Color.BLACK);
		btnNewButton_2_3_1.setBounds(638, 301, 213, 40);
		mainPanel.add(btnNewButton_2_3_1);
		
	}

	protected void openWebsite(String url) {
		try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
	}

	protected void dispose(EventObject e) {
	    Component source = (Component) e.getSource();
	    JFrame owner = (JFrame) SwingUtilities.getWindowAncestor(source);
	    if (owner != null) {
	        owner.dispose();
	    }
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
