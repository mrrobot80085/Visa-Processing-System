package VisaGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class HomeLog extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeLog frame = new HomeLog();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomeLog() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 895, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel sidebarPanel = new JPanel();
		sidebarPanel.setLayout(null);
		sidebarPanel.setBackground(Color.BLACK);
		sidebarPanel.setBounds(711, 52, 150, 164);
		contentPane.add(sidebarPanel);
		
		JButton btnNewButton_1 = new JButton("Student ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student st = new Student();
				st.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1.setBackground(Color.BLACK);
		btnNewButton_1.setBounds(0, 0, 160, 43);
		sidebarPanel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Tourist");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tourist tv = new Tourist();
				tv.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1_1.setBackground(Color.BLACK);
		btnNewButton_1_1.setBounds(0, 39, 150, 43);
		sidebarPanel.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("Docs To Carry");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DocsToCarry dtc = new DocsToCarry();
				dtc.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1_1_1.setBackground(Color.BLACK);
		btnNewButton_1_1_1.setBounds(-1, 81, 150, 43);
		sidebarPanel.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_2 = new JButton("Log Out");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home hm = new Home();
				hm.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home hm = new Home();
				hm.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1_2.setForeground(Color.WHITE);
		btnNewButton_1_1_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_1_1_2.setBackground(Color.BLACK);
		btnNewButton_1_1_2.setBounds(-2, 121, 150, 43);
		sidebarPanel.add(btnNewButton_1_1_2);
		
		sidebarPanel.setLayout(null);
		sidebarPanel.add(btnNewButton_1);
		sidebarPanel.add(btnNewButton_1_1);
		sidebarPanel.add(btnNewButton_1_1_1);
		sidebarPanel.add(btnNewButton_1_1_2);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 50, 883, 30);
		contentPane.add(panel);
		
		JButton btnNewButton_3 = new JButton("HOME");
		btnNewButton_3.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_3.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(236, 1, 89, 30);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("ABOUT US");
		btnNewButton_3_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3_1.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_3_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3_1.setBorderPainted(false);
		btnNewButton_3_1.setBackground(Color.WHITE);
		btnNewButton_3_1.setBounds(324, 1, 128, 30);
		panel.add(btnNewButton_3_1);
		
		JButton btnNewButton_3_1_1 = new JButton("CONTACT US\r\n");
		btnNewButton_3_1_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3_1_1.setHorizontalAlignment(SwingConstants.LEADING);
		btnNewButton_3_1_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3_1_1.setBorderPainted(false);
		btnNewButton_3_1_1.setBackground(Color.WHITE);
		btnNewButton_3_1_1.setBounds(452, 1, 151, 30);
		panel.add(btnNewButton_3_1_1);
        
        // Declare sidebarVisible variable
        JButton btnNewButton = new JButton("");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sidebarPanel.setVisible(!sidebarPanel.isVisible());
            }
        });
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Blank diagram - Page 3 (5) (1).png"));
		btnNewButton.setOpaque(false);
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setBounds(843, 11, 30, 30);
		contentPane.add(btnNewButton);
		
		JButton twitter = new JButton("");
        twitter.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Untitled design (1)\\1.png"));
        twitter.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		openWebsite("https://www.twitter.com");
        	}
        });
	    btnNewButton.setOpaque(false);
	    btnNewButton.setBackground(null);
        twitter.setBounds(774, 10, 30, 30);
        contentPane.add(twitter);
        
        JButton facebook = new JButton("");
        facebook.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Untitled design (1)\\2.png"));
        facebook.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		openWebsite("https://www.facebook.com");
        	}
        });

	    btnNewButton.setOpaque(false);
	    btnNewButton.setBackground(null);
        facebook.setBounds(724, 10, 30, 30);
        contentPane.add(facebook);
        
        JButton instagram = new JButton("");
        instagram.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Untitled design (1)\\3.png"));
        instagram.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		openWebsite("https://www.instagram.com");
        	}
        });
	    btnNewButton.setOpaque(false);
	    btnNewButton.setBackground(null);
        instagram.setBounds(675, 10, 30, 30);
		contentPane.add(instagram);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(null);
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBounds(16, 91, 851, 340);
		contentPane.add(mainPanel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\travel the world hassle free.png"));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setBounds(0, 0, 851, 302);
		mainPanel.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Apply For Student Visa");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student st = new Student();
				st.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2.setBackground(Color.BLACK);
		btnNewButton_2.setBounds(0, 301, 213, 40);
		mainPanel.add(btnNewButton_2);
		
		JButton btnNewButton_2_2 = new JButton("Apply for Tourist Visa");
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tourist tv = new Tourist();
				tv.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2_2.setForeground(Color.WHITE);
		btnNewButton_2_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2_2.setBackground(Color.BLACK);
		btnNewButton_2_2.setBounds(212, 301, 213, 40);
		mainPanel.add(btnNewButton_2_2);
		
		JButton btnNewButton_2_3 = new JButton("Important Documents");
		btnNewButton_2_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DocsToCarry dtc = new DocsToCarry();
				dtc.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2_3.setForeground(Color.WHITE);
		btnNewButton_2_3.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2_3.setBackground(Color.BLACK);
		btnNewButton_2_3.setBounds(424, 301, 213, 40);
		mainPanel.add(btnNewButton_2_3);
		
		JButton btnNewButton_2_3_1 = new JButton("About Us");
		btnNewButton_2_3_1.setForeground(Color.WHITE);
		btnNewButton_2_3_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		btnNewButton_2_3_1.setBackground(Color.BLACK);
		btnNewButton_2_3_1.setBounds(638, 301, 213, 40);
		mainPanel.add(btnNewButton_2_3_1);
		
		JLabel lblNewLabel = new JLabel("Visa");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Castellar", Font.BOLD, 35));
		lblNewLabel.setBackground(new Color(5, 5, 5));
		lblNewLabel.setBounds(40, 0, 165, 51);
		contentPane.add(lblNewLabel);
		
		
	}

	protected void openWebsite(String url) {
		try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
		
	}
}
