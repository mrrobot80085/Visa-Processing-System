package VisaGUI;

import JDBC.CreateDatabase;
import JDBC.CreateTable;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class Login extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtEmail;
    private JPasswordField txtPassword;
    private String option;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
        	public void run() {
            try {
                Login frame = new Login("Login");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        	}
        });
    }
    public boolean validateLogin(String email, String Upassword) {
    	// JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);
        boolean isValid = false;
        Connection conn = null;
        //Statement stmt = null;
        try {
        	

            // Open a connection
            System.out.println("Successfully Connected to database...");
            conn = DriverManager.getConnection(dbUrl+dbName, username, password);

           // Execute a query
           //stmt = conn.createStatement();
            String query = "SELECT * FROM vps_userdata WHERE email = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, Upassword);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                isValid = true;
            }
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return isValid;
    }


    public Login(String option) {
        setResizable(false);
        this.option = option;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 895, 500);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnNewButton_1 = new JButton("Login");
        btnNewButton_1.setForeground(Color.BLACK);
        btnNewButton_1.setBackground(new Color(0, 128, 255));
        btnNewButton_1.setFont(new Font("SansSerif", Font.BOLD, 20));
        btnNewButton_1.addActionListener(new ActionListener() {
            
        	public void actionPerformed(ActionEvent e) {
                String email = txtEmail.getText();
                String password = new String(txtPassword.getPassword());
                
                //isValidUser(email, password);
                boolean isVal = validateLogin(email,password);

                if (isVal) {
                    if (option.equals("Student")) {
                        Student studentFrame = new Student();
                        studentFrame.setVisible(true);
                    } else if (option.equals("Tourist")) {
                        Tourist touristFrame = new Tourist();
                        touristFrame.setVisible(true);
                    } else if (option.equals("DocsToCarry")) {
                        DocsToCarry Frame = new DocsToCarry();
                        Frame.setVisible(true);
                    } else if (option.equals("HomeLog")) {
                        HomeLog Frame = new HomeLog();
                        Frame.setVisible(false);
                        HomeLog newFrame = new HomeLog();
                        newFrame.setVisible(true);
                    }
                    dispose(); // hide the login frame
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid email or password. Please try again.");
                }
        	
           }

            private boolean isValidUser(String email, String password) {
                boolean isValid = false;
                try (Scanner scanner = new Scanner(new File("C:\\Users\\sid13\\GUI\\src\\VisaGUI\\users.txt"))) {
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        String[] fields = line.split(",");
                        if (fields[0].equals(email) && fields[1].equals(password)) {
                            isValid = true;
                            break;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                if (email.equals("admin@admin.com") && password.equals("admin123")) {
                    isValid = true;
                }
                return isValid;
            }
        });
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					Home home = new Home();
					home.frame.setVisible(true);
				   dispose();
			}
		});
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Blank diagram - Page 4 (1) (1).png"));
		btnNewButton_2.setBounds(10, 11, 40, 40);
		btnNewButton_2.setOpaque(false);
	    btnNewButton_2.setBackground(null);
		contentPane.add(btnNewButton_2);

        
		JButton btnNewButton_1_1_1 = new JButton("CONTINUE WITH FACEBOOK");
		btnNewButton_1_1_1.setForeground(Color.BLACK);
		btnNewButton_1_1_1.setFont(new Font("SansSerif", Font.BOLD, 16));
		btnNewButton_1_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Open a browser window to the Google login page
		            Desktop.getDesktop().browse(new URI("https://www.facebook.com/login/"));
		        } catch (IOException | URISyntaxException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btnNewButton_1_1_1.setBounds(310, 383, 276, 33);
		contentPane.add(btnNewButton_1_1_1);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBackground(new Color(255, 255, 255));
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\double-line-download-picture-free-transparent-28.png"));
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setBounds(284, 287, 321, 7);
		contentPane.add(lblNewLabel_6);
		
		txtPassword = new JPasswordField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(310, 175, 276, 30);
		contentPane.add(txtPassword);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtEmail.setBounds(310, 110, 276, 30);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);

		btnNewButton_1.setFont(new Font("SansSerif", Font.BOLD, 20));
		btnNewButton_1.setBounds(310, 241, 276, 33);
		contentPane.add(btnNewButton_1);
		
	    JButton btnNewButton = new JButton("Forgot Password?");
	    btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
	    btnNewButton.setForeground(new Color(242, 242, 242));
	    btnNewButton.setOpaque(false);
	    btnNewButton.setBackground(null);
	    btnNewButton.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
//	            JOptionPane optionPane = new JOptionPane("Please contact customer service to reset your password.", JOptionPane.INFORMATION_MESSAGE);
//	            JDialog dialog = optionPane.createDialog("Forgot Password");
//	            dialog.setLocation(352, 280);
//	            dialog.setVisible(true);
	        	
	        	forgetPassword fPObj = new forgetPassword();
	            fPObj.setVisible(true);
	        }
	    });
	    btnNewButton.setBounds(366, 211, 168, 25);
	    contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Login");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 35));
		lblNewLabel_1.setBounds(382, 57, 134, 42);
		contentPane.add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 485, 875, -482);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBackground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 14));
		lblNewLabel_3.setBounds(310, 85, 67, 24);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 14));
		lblNewLabel_3.setLabelFor(lblNewLabel_4);
		lblNewLabel_4.setBounds(310, 152, 82, 13);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_1_1 = new JButton("CONTINUE WITH GOOGLE");
		btnNewButton_1_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Open a browser window to the Google login page
		            Desktop.getDesktop().browse(new URI("https://accounts.google.com/login"));
		        } catch (IOException | URISyntaxException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btnNewButton_1_1.setForeground(new Color(0, 0, 0));
		btnNewButton_1_1.setFont(new Font("Mongolian Baiti", Font.BOLD, 16));
		btnNewButton_1_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1_1.setBounds(311, 339, 276, 33);
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_3 = new JButton("Create Account");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignUp su = new SignUp(null);
				su.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setFont(new Font("Leelawadee UI", Font.BOLD, 18));
		btnNewButton_3.setOpaque(false);
		btnNewButton_3.setBackground(null);
		btnNewButton_3.setBounds(368, 300, 171, 31);
		contentPane.add(btnNewButton_3);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Untitled design (24).png"));
		lblNewLabel.setBounds(0, 0, 883, 465);
		contentPane.add(lblNewLabel);
		
	}
}
