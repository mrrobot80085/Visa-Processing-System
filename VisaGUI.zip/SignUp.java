package VisaGUI;

import javax.swing.JOptionPane;

import JDBC.CreateDatabase;
import JDBC.CreateTable;
import JDBC.InsertData;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class SignUp extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textName;
    private JPasswordField passwordField;
    private JPasswordField passwordField_1;
    private JTextField textEmail;
    static int count = 0;
    String jdbcDriver = "com.mysql.jdbc.Driver";
    String dbUrl = "jdbc:mysql://localhost/";
    String dbName = "VisaProcessingSystem";
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
        	public void run() {
            try {
                SignUp frame = new SignUp("SignUp");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        	}
        });
    }
    public void Create_Database(){
    	// JDBC driver name and database URL
        String jdbcDriver = "com.mysql.jdbc.Driver";
        String dbUrl = "jdbc:mysql://localhost/";
        String dbName = "VisaProcessingSystem";
        
        File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
        ArrayList<String> lines = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line); // Append line to ArrayList
            }

            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Print the lines ArrayList
        //for (String line : lines) {
        //    System.out.println(line);
        //}


        // Database credentials
        String username = lines.get(0);
        String password = lines.get(1);

        Connection conn = null;
        Statement stmt = null;

        //Scanner input = new Scanner(System.in);
        //System.out.print("Enter the name of the database: ");
        //String dbName = input.nextLine();
        

        try {
            // Register JDBC driver
            Class.forName(jdbcDriver);

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(dbUrl, username, password);

            // Execute a query to create a new database
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String sql = "CREATE DATABASE IF NOT EXISTS " + dbName;
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully.");

        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
       
      create_logs(dbName);
    }
    
    public void create_logs(String dbname) {
          String jdbcDriver = "com.mysql.jdbc.Driver";
          String dbUrl = "jdbc:mysql://localhost/";
          
          File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
          ArrayList<String> lines = new ArrayList<>();

          try {
              Scanner scanner = new Scanner(file);

              while (scanner.hasNextLine()) {
                  String line = scanner.nextLine();
                  lines.add(line); // Append line to ArrayList
              }

              scanner.close();

          } catch (FileNotFoundException e) {
              e.printStackTrace();
          }

          // Print the lines ArrayList
          //for (String line : lines) {
          //    System.out.println(line);
          //}


          // Database credentials
          String username = lines.get(0);
          String password = lines.get(1);

          Connection conn = null;
          Statement stmt = null;

          try {
              // Register JDBC driver
              Class.forName(jdbcDriver);

              // Open a connection
              System.out.println("Connecting to database...");
              conn = DriverManager.getConnection(dbUrl, username, password);
              
              String dbName = dbname + "_logs";
              
           // Execute a query to create a new database
              System.out.println("Creating database...");
              stmt = conn.createStatement();
              String sql = "CREATE DATABASE IF NOT EXISTS " + dbName;
              stmt.executeUpdate(sql);
              System.out.println("Database created successfully.");

          } catch (SQLException se) {
              // Handle errors for JDBC
              se.printStackTrace();
          } catch (Exception e) {
              // Handle errors for Class.forName
              e.printStackTrace();
          } finally {
              // Close resources
              try {
                  if (stmt != null)
                      stmt.close();
              } catch (SQLException se) {
                  se.printStackTrace();
              }
              try {
                  if (conn != null)
                      conn.close();
              } catch (SQLException se) {
                  se.printStackTrace();
              }
          }
      }
public void Create_UserData(String uName,String uPassword,String uEmail,String uCPassword) {
    	
    	//if (uPassword == uCPassword) //get it from text field
    	//{
    		   String jdbcDriver = "com.mysql.jdbc.Driver";
    	       String dbUrl = "jdbc:mysql://localhost/";
    	       String dbName = "VisaProcessingSystem";
    	       String tbName = "VPS_UserData";
    	       
    	       CreateDatabase.main(null);
    	       File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
    	       ArrayList<String> lines = new ArrayList<>();

    	       try {
    	           Scanner scanner = new Scanner(file);

    	           while (scanner.hasNextLine()) {
    	               String line = scanner.nextLine();
    	               lines.add(line); // Append line to ArrayList
    	           }

    	           scanner.close();

    	       } catch (FileNotFoundException e) {
    	           e.printStackTrace();
    	       }
    	    // Database credentials
    	       String username = lines.get(0);
    	       String password = lines.get(1);

    	       Connection conn = null;
    	       Statement stmt = null;
    	       try {
    	        	  // Register JDBC driver
    	              Class.forName(jdbcDriver);

    	              // Open a connection
    	              System.out.println("Connecting to database...");
    	              conn = DriverManager.getConnection(dbUrl+dbName, username, password);

    	             // Execute a query
    	             stmt = conn.createStatement();
    	             String sql = "CREATE TABLE IF NOT EXISTS " + tbName + 
    	                          "(ID INTEGER not NULL, " +
    	                          " Name VARCHAR(255), " +
    	                          " Email VARCHAR(255), " +
    	                          " Password VARCHAR(255), " +
    	                          " PRIMARY KEY ( ID ))";
    	             stmt.executeUpdate(sql);
    	             System.out.println("Table created successfully...");
    	             int c = getLastInsertedID(tbName);
    	             count++;
    	             insertUserData(tbName,c+=1,uName,uEmail,uPassword);
    	             
    	          } catch (SQLException se) {
    	             // Handle errors for JDBC
    	             se.printStackTrace();
    	          } catch (Exception e) {
    	             // Handle errors for Class.forName
    	             e.printStackTrace();
    	          } finally {
    	             // finally block used to close resources
    	             try {
    	                if (stmt != null)
    	                   conn.close();
    	             } catch (SQLException se) {
    	             } // do nothing
    	             try {
    	                if (conn != null)
    	                   conn.close();
    	             } catch (SQLException se) {
    	                se.printStackTrace();
    	             } // end finally try
    	          } // end try
    	//}
   }
public void insertUserData(String tbName,
        int id, String uName, String uEmail, String uPassword) {
	try {
		String query = "INSERT INTO " + tbName +  " (ID, Name, Email, Password) " +
		     "VALUES (?, ?, ?, ?)";
		File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
	       ArrayList<String> lines = new ArrayList<>();

	       try {
	           Scanner scanner = new Scanner(file);

	           while (scanner.hasNextLine()) {
	               String line = scanner.nextLine();
	               lines.add(line); // Append line to ArrayList
	           }

	           scanner.close();

	       } catch (FileNotFoundException e) {
	           e.printStackTrace();
	       }
	    // Database credentials
	       String username = lines.get(0);
	       String password = lines.get(1);
		// Establish a connection to the database
		Connection conn = DriverManager.getConnection(dbUrl+dbName, username, password);
		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setInt(1, id);
		stmt.setString(2, uName);
		stmt.setString(3, uEmail);
		stmt.setString(4, uPassword);

		stmt.executeUpdate();
		System.out.println("Data inserted successfully!");
		} catch (SQLException ex) {
		System.out.println("Error: " + ex.getMessage());
		}
}
public int getLastInsertedID(String tbName) {
	// JDBC driver name and database URL
    String jdbcDriver = "com.mysql.jdbc.Driver";
    String dbUrl = "jdbc:mysql://localhost/";
    String dbName = "VisaProcessingSystem";
    
    File file = new File("D:\\Eclipse Workplace\\GUI\\src\\JDBC\\user_pass.txt");
    ArrayList<String> lines = new ArrayList<>();

    try {
        Scanner scanner = new Scanner(file);

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            lines.add(line); // Append line to ArrayList
        }

        scanner.close();

    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }

    // Print the lines ArrayList
    //for (String line : lines) {
    //    System.out.println(line);
    //}


    // Database credentials
    String username = lines.get(0);
    String password = lines.get(1);

    //Connection conn = null;
    //Statement stmt = null;
    int id = 0;
    try {
    	Connection conn = DriverManager.getConnection(dbUrl+dbName, username, password);
        String query = "SELECT ID FROM " + tbName + " ORDER BY ID DESC LIMIT 1";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            id = rs.getInt("ID");
        }
        conn.close();
    } catch (SQLException ex) {
        System.out.println("Error: " + ex.getMessage());
    }
    return id;
}

    
    

    public SignUp(String option) {
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 895, 500);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("");		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home hm = new Home();
				hm.frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setOpaque(false);
	    btnNewButton_2.setBackground(null);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setColumns(10);
		
		
		JLabel lblNewLabel_2 = new JLabel("OR");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Castellar", Font.BOLD, 16));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(424, 305, 40, 40);
		contentPane.add(lblNewLabel_2);
		
		textEmail = new JTextField();
		textEmail.setBounds(310, 162, 276, 30);
		contentPane.add(textEmail);
		textEmail.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(10);
		passwordField.setBounds(310, 217, 276, 30);
		contentPane.add(passwordField);
		passwordField_1.setBounds(310, 275, 276, 30);
		contentPane.add(passwordField_1);
		
		textName = new JTextField();
		textName.setColumns(10);
		textName.setBounds(310, 104, 276, 30);
		contentPane.add(textName);
		
		JButton btnNewButton_1_2 = new JButton("FACEBOOK");
		btnNewButton_1_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Open a browser window to the Google login page
		            Desktop.getDesktop().browse(new URI("https://www.facebook.com/login/"));
		        } catch (IOException | URISyntaxException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btnNewButton_1_2.setForeground(Color.BLACK);
		btnNewButton_1_2.setFont(new Font("Mongolian Baiti", Font.BOLD, 14));
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(452, 342, 117, 30);
		contentPane.add(btnNewButton_1_2);
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Blank diagram - Page 4 (1) (1).png"));
		btnNewButton_2.setBounds(10, 11, 40, 40);
		btnNewButton_2.setOpaque(false);
	    btnNewButton_2.setBackground(null);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBackground(new Color(192, 192, 192));
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\double-line-download-picture-free-transparent-28.png"));
		lblNewLabel_6.setForeground(new Color(192, 192, 192));
		lblNewLabel_6.setBounds(287, 322, 140, 3);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_4_2 = new JLabel("Password");
		lblNewLabel_4_2.setForeground(Color.WHITE);
		lblNewLabel_4_2.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 14));
		lblNewLabel_4_2.setBounds(310, 198, 82, 13);
		contentPane.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("Confirm Password");
		lblNewLabel_4_2_1.setForeground(Color.WHITE);
		lblNewLabel_4_2_1.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 14));
		lblNewLabel_4_2_1.setBounds(310, 256, 117, 13);
		contentPane.add(lblNewLabel_4_2_1);
		
		JLabel lblNewLabel_1 = new JLabel("Sign Up");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 36));
		lblNewLabel_1.setBounds(360, 52, 161, 42);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Name");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBackground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 14));
		lblNewLabel_3.setBounds(310, 79, 67, 24);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Email");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Leelawadee UI Semilight", Font.BOLD, 14));
		lblNewLabel_3.setLabelFor(lblNewLabel_4);
		lblNewLabel_4.setBounds(310, 140, 82, 13);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_1 = new JButton("GOOGLE");
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Open a browser window to the Google login page
		            Desktop.getDesktop().browse(new URI("https://accounts.google.com/login"));
		        } catch (IOException | URISyntaxException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setFont(new Font("Mongolian Baiti", Font.BOLD, 14));
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(325, 342, 117, 30);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_6_1 = new JLabel("");
		lblNewLabel_6_1.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\double-line-download-picture-free-transparent-28.png"));
		lblNewLabel_6_1.setForeground(Color.LIGHT_GRAY);
		lblNewLabel_6_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_6_1.setBounds(461, 322, 140, 3);
		contentPane.add(lblNewLabel_6_1);
		
		JButton btnNewButton = new JButton("Sign In");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    // get the form data
			    String name = textName.getText().trim();
			    String email = textEmail.getText().trim();
			    String password = new String(passwordField.getPassword());
			    String confirmPassword = new String(passwordField_1.getPassword());
			    Create_Database();
			    //try {
			        // validate the form data
			        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
			            JOptionPane.showMessageDialog(contentPane, "Please fill all fields.");
			        } else if (!isValidEmail(email)) {
			            JOptionPane.showMessageDialog(contentPane, "Invalid email address.");
			        } else if (!password.equals(confirmPassword)) {
			            JOptionPane.showMessageDialog(contentPane, "Passwords do not match.");
			        } else {
			        	Create_UserData(name,password,email,confirmPassword);
			        	//count++;
	    	    	    //insertUserData(tbName,count, name, email, password); //name mail pass get from text field
			        	JOptionPane.showMessageDialog(contentPane, "User created successfully.");
			            HomeLog hl = new HomeLog();
			            hl.setVisible(true);
			            dispose();
			        }
			    //} catch (IllegalArgumentException ex) {
			    //    JOptionPane.showMessageDialog(contentPane, ex.getMessage());
			    //}
			    
			}

			private boolean isValidEmail(String email) {
				String regex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
			    Pattern pattern = Pattern.compile(regex);
			    Matcher matcher = pattern.matcher(email);
			    if (matcher.matches()) {
			        return true;
			    } else {
			        throw new IllegalArgumentException("Invalid email address.");
			    }  
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 128, 255));
		btnNewButton.setFont(new Font("MS UI Gothic", Font.BOLD, 16));
		btnNewButton.setBounds(401, 384, 90, 30);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Untitled design (3)\\3.png"));
		lblNewLabel.setBounds(0, 0, 883, 465);
		contentPane.add(lblNewLabel);
		
    }
}
