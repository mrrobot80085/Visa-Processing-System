package VisaGUI;

import java.awt.EventQueue;
import USA.USATour;
import CANADA.CANADATour;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;

public class Tourist extends JFrame {
	

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tourist() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 895, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 64));
		contentPane.setForeground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(411, 186, 301, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(805, 721, -801, -725);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("TOURIST VISA APPLICATION ");
		lblNewLabel.setBounds(125, 97, 627, 68);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 45));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME:");
		lblNewLabel_1.setBounds(154, 193, 77, 26);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 20));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("SELECT COUNTRY:");
		lblNewLabel_2.setBounds(154, 241, 190, 33);
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("SansSerif", Font.BOLD, 20));
		contentPane.add(lblNewLabel_2);
		
		JScrollPane scrollPane1 = new JScrollPane();
		scrollPane1.setBounds(805, 721, -801, -725);
		contentPane.add(scrollPane1);

		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBounds(411, 241, 301, 33);
		comboBox.setEditable(true);
		comboBox.setToolTipText("");
		comboBox.setModel(new DefaultComboBoxModel<>(new String[] {"Select a Option","United States of America", "Canada", "United Kingdom", "Germany", "Japan"}));
		comboBox.setSelectedIndex(0);
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.setBounds(486, 308, 146, 40);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String country = (String)comboBox.getSelectedItem();
				switch(country) {
				case "United States of America":
					USATour usa = new USATour();
					usa.setVisible(true);
					usa.setBounds(100, 100, 895, 500);
					usa.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					break;
				case "Canada":
					CANADATour can = new CANADATour();
					can.setVisible(true);
					can.setBounds(100, 100, 895, 500);
					can.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					break;
				case "UK":
					UnitedKingdom uk = new UnitedKingdom();
					uk.setVisible(true);
					uk.setBounds(100, 100, 895, 500);
					uk.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					break;
				case "Germany":
					Germany ger = new Germany();
					ger.setVisible(true);
					ger.setBounds(100, 100, 895, 500);
					ger.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					break;
				case "Japan":
					Japan jap = new Japan();
					jap.setVisible(true);
					jap.setBounds(100, 100, 895, 500);
					jap.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					break;
				default:
					break;
				}
				dispose();
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 128, 255));
		btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 20));
		contentPane.add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home hm = new Home();
				hm.setVisible(true);
				dispose();
			}
		});
		btnBack.setForeground(new Color(255, 255, 255));
		btnBack.setFont(new Font("SansSerif", Font.BOLD, 20));
		btnBack.setBackground(new Color(192, 192, 192));
		btnBack.setBounds(240, 308, 146, 40);
		contentPane.add(btnBack);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 50, 883, 30);
		contentPane.add(panel);
		
		JButton btnNewButton_3 = new JButton("HOME");
		btnNewButton_3.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(188, 1, 155, 30);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("ABOUT US");
		btnNewButton_3_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3_1.setBorderPainted(false);
		btnNewButton_3_1.setBackground(Color.WHITE);
		btnNewButton_3_1.setBounds(341, 1, 155, 30);
		panel.add(btnNewButton_3_1);
		
		JButton btnNewButton_3_1_1 = new JButton("CONTACT US\r\n");
		btnNewButton_3_1_1.setVerticalAlignment(SwingConstants.BOTTOM);
		btnNewButton_3_1_1.setFont(new Font("Microsoft JhengHei UI Light", Font.BOLD, 16));
		btnNewButton_3_1_1.setBorderPainted(false);
		btnNewButton_3_1_1.setBackground(Color.WHITE);
		btnNewButton_3_1_1.setBounds(494, 1, 155, 30);
		panel.add(btnNewButton_3_1_1);
		
//		JLabel lblNewLabel_3 = new JLabel("");
//		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\sid13\\Downloads\\Untitled design (36).png"));
//		lblNewLabel_3.setBounds(0, 0, 883, 465);
//		contentPane.add(lblNewLabel_3);
		}
}		