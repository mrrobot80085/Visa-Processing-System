package VisaGUI;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.*;

public class forgetPassword extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel usernameLabel;
    private JTextField usernameField;
    private JLabel newPasswordLabel;
    private JPasswordField newPasswordField;
    private JButton setPasswordButton;

    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "2003";
    private static final String DBNAME = "visaprocessingsystem";
    private static final String TBNAME = "VPS_userdata";

    public forgetPassword() {

        // Set the title of the JFrame
        setTitle("Password Reset");

        // Create and set layout for the main JPanel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // Create the username field and add it to the main JPanel
        usernameLabel = new JLabel("Username:");
        mainPanel.add(usernameLabel);
        usernameField = new JTextField(20);
        mainPanel.add(usernameField);

        // Create the new password field and add it to the main JPanel
        newPasswordLabel = new JLabel("New Password:");
        mainPanel.add(newPasswordLabel);
        newPasswordField = new JPasswordField(20);
        mainPanel.add(newPasswordField);

        // Create the Set Password button and add it to the main JPanel
        setPasswordButton = new JButton("Set Password");
        setPasswordButton.addActionListener(e -> updatePassword());
        mainPanel.add(setPasswordButton);

        // Add the main JPanel to the JFrame's content pane
        getContentPane().add(mainPanel);

        // Set the size of the JFrame and make it visible
        setSize(400, 200);
        setVisible(true);

    }

    private void updatePassword() {
        String usernameToUpdate = usernameField.getText();
        String newPassword = String.valueOf(newPasswordField.getPassword());

        try (Connection conn = DriverManager.getConnection(URL+DBNAME, USERNAME, PASSWORD)) {
            String sql = "UPDATE " + TBNAME + " SET Password = ? WHERE Name = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, newPassword);
            stmt.setString(2, usernameToUpdate);

            int rowsAffected = stmt.executeUpdate();

            System.out.println(rowsAffected + " rows updated.");

            JOptionPane.showMessageDialog(this, "Password updated successfully.");
            dispose();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating password: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
    	forgetPassword form = new forgetPassword();
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
